﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BusinessException.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   BusinessException created at  3/10/2018 9:59:48 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
using System;
using System.Net;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// 业务异常
    /// </summary>
    public class BusinessException : ApplicationException
    {
        /// <summary>
        /// 业务错误的代码
        /// </summary>
        public string ErrorCode { get; set; }

        /// <summary>
        /// HTTP状态码
        /// </summary>
        public HttpStatusCode StatusCode { get; set; }

        /// <summary>
        /// 业务异常
        /// </summary>
        /// <param name="errorMessage">异常消息</param>
        /// <param name="errorCode">微服务中的业务异常代码</param>
        /// <param name="statusCode">http状态码，默认400</param>
        /// <param name="innerException">要包括的异常</param>
        public BusinessException(
            string errorMessage,
            string errorCode = "CM00000",
            HttpStatusCode statusCode = HttpStatusCode.BadRequest,
            Exception innerException = null)
            : base(errorMessage ?? errorCode, innerException)
        {
            this.ErrorCode = errorCode;
            this.StatusCode = statusCode;
        }
    }
}