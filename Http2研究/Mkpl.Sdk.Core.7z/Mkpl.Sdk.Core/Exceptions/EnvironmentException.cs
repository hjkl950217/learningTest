﻿using System;

namespace Mkpl.Sdk.Core.Exceptions
{
    /// <summary>
    /// 环境方面的异常
    /// </summary>
    public class EnvironmentException : ApplicationException
    {
        public EnvironmentException() : base("An environmental error has occurred, please check the environment variable")
        {
        }

        /// <summary>
        /// 用指定的错误消息初始化 Mkpl.Sdk.Core.Exceptions.EnvironmentException 类的新实例。
        /// </summary>
        /// <param name="message">错误描述</param>
        public EnvironmentException(string message) : base(message)
        {
        }

        /// <summary>
        /// 使用指定的错误消息和对引起此异常的内部异常的引用初始化
        /// Mkpl.Sdk.Core.Exceptions.EnvironmentException 类的新实例。。
        /// </summary>
        /// <param name="message">错误描述</param>
        /// <param name="innerException">如果没有指定内部异常，则导致当前异常的异常或空引用
        /// （在Visual Basic中为Nothing）。
        /// </param>
        public EnvironmentException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// 使用指定的错误消息和对引起此异常的内部异常的引用初始化
        /// Mkpl.Sdk.Core.Exceptions.EnvironmentException 类的新实例。。
        /// </summary>
        /// <param name="message">错误描述</param>
        /// <param name="environmentName">发生错误的环境变量名
        /// </param>
        public EnvironmentException(string message, string environmentName)
            : base($"{message},Exception Environment:{environmentName}") { }

        /// <summary>
        /// 使用指定的错误消息和对引起此异常的内部异常的引用初始化
        /// Mkpl.Sdk.Core.Exceptions.EnvironmentException 类的新实例。。
        /// </summary>
        /// <param name="message">错误描述</param>
        /// <param name="environmentName">发生错误的环境变量名
        /// <param name="innerException">如果没有指定内部异常，则导致当前异常的异常或空引用
        /// （在Visual Basic中为Nothing）。
        /// </param>
        /// </param>
        public EnvironmentException(string message, string environmentName, Exception innerException)
          : base($"{message},Exception Environment:{environmentName}", innerException) { }
    }
}