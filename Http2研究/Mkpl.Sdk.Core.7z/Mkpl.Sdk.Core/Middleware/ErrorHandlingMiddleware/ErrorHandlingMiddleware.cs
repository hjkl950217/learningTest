﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ErrorHandlingExtensions.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   ErrorHandlingExtensions created at  3/20/2018 3:27:20 PM
// </summary>
//<Description>
// edit   lynn   2018-04-04
//</Description>
// --------------------------------------------------------------------------------------------------------------------
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Helpers;
using Newegg.MIS.Baymax.Config;
using System;
using System.Net;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// mps exception Middleware
    /// </summary>
    public class ErrorHandlingMiddleware
    {
        private readonly RequestDelegate nextMiddleware;
        private readonly ILogger logger;
#pragma warning disable S1450 // Private fields only used as local variables in methods should become local variables
        private readonly ISdkConfig sdkConfig;
#pragma warning restore S1450 // Private fields only used as local variables in methods should become local variables

        /// <summary>
        /// 初始化错误处理中间件
        /// </summary>
        /// <param name="next"></param>
        /// <param name="sdkConfig"></param>
        /// <param name="loggerProvider"></param>
        public ErrorHandlingMiddleware(RequestDelegate next, ISdkConfig sdkConfig, ILoggerProvider loggerProvider)
        {
            this.nextMiddleware = next;
            this.sdkConfig = sdkConfig;
            this.logger = loggerProvider.CreateLogger(this.sdkConfig.LogCategoryName);
        }

        /// <summary>
        /// 执行中间件逻辑
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task Invoke(HttpContext context)
        {
            try
            {
                //调用下一个中间件
                await this.nextMiddleware(context);
            }
            catch (BusinessException ex)
            {
                //抛出业务异常
                await HandleBusinessExceptionAsync(context, ex);
            }
            catch (Exception ex)
            {
                //抛出程序异常
                string errorId = Guid.NewGuid()
                    .ToString()
                    .ToUpper();

                this.logger.LogError($"{ex.ToString()}.ErrorID:{errorId}");
                await HandleExceptionAsync(context, ex, errorId);
            }
            finally
            {
                //其它异常
                var data = context.Features.Get<IExceptionHandlerPathFeature>();
                if (data != null && data.Error != null)
                {
                    await HandleExceptionAsync(context, data.Error);
                }
            }
        }

        #region 异常处理

        /// <summary>
        /// 业务异常抛出
        /// </summary>
        /// <param name="context"></param>
        /// <param name="ex"></param>
        /// <returns></returns>
        private Task HandleBusinessExceptionAsync(HttpContext context, BusinessException ex)
        {
            context.Response.StatusCode = (int)ex.StatusCode;
            context.Response.ContentType = ContentTypeConst.Json;

            var response = new ExceptionOut
            {
                ResponseCode = ex.ErrorCode,
                Message = ex.Message,
                StatusCode = ex.StatusCode,
                StackTrace = string.Empty,
                Path = string.Empty
            };

            return context.Response.WriteAsync(response.ToJsonExt());
        }

        /// <summary>
        /// 原始异常抛出
        /// </summary>
        /// <param name="context">http上下文</param>
        /// <param name="ex">捕捉到的异常</param>
        /// <param name="errorId">已经纪录下日志的错误号</param>
        /// <returns></returns>
        private Task HandleExceptionAsync(HttpContext context, Exception ex, string errorId = null)
        {
            int statusCode = context.Response.StatusCode;
            if (statusCode < 500) statusCode = 500;

            context.Response.StatusCode = statusCode;
            context.Response.ContentType = ContentTypeConst.Json;
            var response = new ExceptionOut
            {
                ResponseCode = "CM0000",
                Message = ex.Message,
                StatusCode = (HttpStatusCode)statusCode,
                StackTrace = ex.StackTrace,
                Path = context.Request.Path
            };

            response = this.PrdMessage(response, errorId);
            return context.Response.WriteAsync(response.ToJsonExt());
        }

        #endregion 异常处理

        #region 其它处理

        /// <summary>
        /// 针对PRD做的异常处理
        /// </summary>
        /// <param name="exceptionOut">要返回出去的异常对象</param>
        ///  <param name="errorid">已经记录日志的错误ID，方便找错</param>
        /// <returns></returns>
        private ExceptionOut PrdMessage(ExceptionOut exceptionOut, string errorId)
        {
            if (EnvHelper.IsPrd() == true)
            {
                exceptionOut.StackTrace = string.Empty;
                exceptionOut.Message = $"There are some exception in our system,We apologize for your inconvenience，please contact with our system administrator.[ErrorId:{errorId}]";
            }

            return exceptionOut;
        }

        #endregion 其它处理
    }
}