﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MpsMQOption.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MpsMQOption created at  5/12/2018 11:30:01 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using System;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// The class of MpsMQOption.
    /// </summary>
    public class MpsMQOption
    {
        /// <summary>
        /// MQ发送者
        /// </summary>
        /// <remarks>
        /// 在注册服务时会初始化，默认不传时使用"Portal2.0"
        /// </remarks>
        public String MQSender { get; set; } = "Portal2.0";
    }
}