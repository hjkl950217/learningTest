﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// NairCache缓存配置
    /// </summary>
    public class NairCacheOption
    {
        /// <summary>
        /// 初始化NairCacheOption实例
        /// </summary>
        /// <remarks>
        /// DefultExpired：默认时间为5分钟
        /// </remarks>
        public NairCacheOption()
        {
            this.DefultExpired = CachaTimeConst.Minute_5;
        }

        /// <summary>
        /// 项目中的默认过期时间,默认5分钟
        /// </summary>
        public int DefultExpired { get; set; }

        /// <summary>
        /// Nair数据库名，相当与表名
        /// </summary>
        public string DatebaseName { get; set; }

        /// <summary>
        /// 密码，默认为null
        /// </summary>
        public string Password { get; set; }
    }
}