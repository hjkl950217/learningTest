﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="NairMiddleware.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   NairMiddleware created at  4/17/2018 10:05:43 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Nair;
using Nair.Sdk;
using Newegg.MIS.EggKeeper.Sdk.Default;
using System;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// MPS组的nair配置中间件
    /// </summary>
    public static class NairExtension
    {
        /// <summary>
        /// 注册Nair-MPS组定制的服务，放在注册其他SDK服务之后,因为数据依赖其他库放入IConfiguration
        /// </summary>
        /// <param name="services"></param>
        /// <param name="setupAction">设置Nair配置的委托</param>
        /// <param name="nairSet">从ConfigService上获取的Nair配置对象实例</param>
        /// <remarks>
        /// 默认的setupAction会从IConfiguration中读取"LogCategoryName"来充当nair的DatebaseName
        /// <para></para>
        /// 默认的nairSet是从IConfiguration中读取"NairSDKSettings"节点。
        /// <para></para>
        /// 默认情况下，Nair的数据库名是服务名+Service。密码为null
        /// </remarks>
        /// <returns></returns>
        public static IServiceCollection AddNairCacheMPS(this IServiceCollection services, Action<NairCacheOption> setupAction = null, NairSDKSettings nairSet = null)
        {
            //调用传入的委托生成Nair配置
            services.AddTransient<NairCacheOption>(t =>
            {
                NairCacheOption nairOpt = new NairCacheOption();

                if (setupAction == null)
                {
                    nairOpt.DatebaseName = t.GetService<IConfiguration>()["LogCategoryName"];
                    if (nairOpt.DatebaseName == null)
                        throw new ArgumentNullException($"Data failed to get from Config Service.", "LogCategoryName");
                }
                else
                {
                    setupAction(nairOpt);//调用传入的委托设置属性
                }

                return nairOpt;
            });

            //从ConfigService上获取Nair配置
            services.AddSingleton<INairFactory>(t =>
            {
                if (nairSet == null)
                    nairSet = t.GetService<IConfiguration>().GetFromJson<NairSDKSettings>("NairSDKSettings");

                if (nairSet == null)
                    throw new ArgumentNullException($"Data failed to get from Config Service.", "NairSDKSettings");

                return new NairFactory(nairSet);
            }); //注入NairFactory

            //配置INairCache对应的实现
            services.AddSingleton<INairCache, NairCache>();

            //注册缓存配置
            services.AddSingletonConfiguration<CacheConfig>();

            return services;
        }
    }
}