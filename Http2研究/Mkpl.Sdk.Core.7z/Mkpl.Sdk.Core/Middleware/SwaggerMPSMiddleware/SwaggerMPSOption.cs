﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SwaggerMPSOption.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   SwaggerMPSOption created at  4/21/2018 4:52:59 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Swashbuckle.AspNetCore.Swagger;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core
{ /// <summary>
  /// MPS组-配置Swagger的模型
  /// </summary>
    public class SwaggerMpsOption
    {
        /// <summary>
        /// 分组的数据
        /// </summary>
        /// <remarks>
        /// 1.项目中有几个GroupName就需要写几乎个
        /// 2.Info的版本信息格式为:v1 v2  需要小写
        /// 3.版本建议传递对应Group中支持的最高版本
        /// 4.没有写GroupName特性的会在所有分组中
        /// </remarks>
        public IList<Info> ConfigList { get; set; }

        /// <summary>
        /// 需要包括的XML注释文件名,需要和对应的WebApi.Dll同级目录
        /// </summary>
        /// <remarks>
        /// 1.不要传递完全限定名
        /// 2.默认可以不传
        /// 3.默认有三个：  "ApiDoc.xml","ApiFacadeDoc.xml","ApiEntityDoc.xml"
        /// 4.要让注释完整显示，需要让web项目的启动根目录有这些文件
        /// </remarks>
        public IList<string> XmlFileNameList { get; set; }

        /// <summary>
        /// 要启用的环境列表。请使用ApplicationEnvConst里面的环境
        /// </summary>
        /// <remarks>
        /// 默认添加 GQC GDEV Development
        /// </remarks>
        public IList<string> EnvEnableList { get; set; }
    }
}