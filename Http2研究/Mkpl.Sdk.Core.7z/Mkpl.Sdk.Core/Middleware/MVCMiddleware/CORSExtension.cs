﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CORSExtensions.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   CORSExtensions created at  4/27/2018 2:12:43 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Microsoft.AspNetCore.Builder;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// The class of CORSExtensions.
    /// </summary>
    public static class CorsExtension
    {
        /// <summary>
        /// 启用MPS组跨域中间件，允许所有跨域
        /// </summary>
        /// <param name="builder"></param>
        /// <param name="otherOrigin">设置newegg以外的来源允许站点,如"newegg.com"</param>
        /// <param name="preflightMaxAgeTicks">
        /// 指定可以缓存对预检请求的响应的时间。<para></para>
        /// 以tick为单位，默认为10分钟
        /// </param>
        /// <returns></returns>
        public static IApplicationBuilder UseAllowCORSMPS(
            this IApplicationBuilder builder,
            Action<List<string>> otherOrigin = null,
            long preflightMaxAgeTicks = 6000000000)
        {
            #region 处理允许集合

            // 早期CORS是使用中间件重写响应头的
            //context.Response.Headers.Add("Access-Control-Allow-Origin" , "*");
            //context.Response.Headers.Add("Access-Control-Allow-Method" , new[] { "*" });
            //context.Response.Headers.Add("Content-Security-Policy" ,
            //    "default-src 'self' *.newegg.org *.newegg.com 10.1.24.130:3000");

            //获取允许集合
            List<string> originList = new List<string>()
            {
                "newegg.org",
                "newegg.com",
                "newegg.cn",
                "localhost"
            };
            otherOrigin?.Invoke(originList);//不为空则用委托附加

            #endregion 处理允许集合

            //配置
            builder.UseCors(t =>
            {
                //预检请求免请求的时间
                TimeSpan time = preflightMaxAgeTicks == 6000000000
                    ? new TimeSpan(TimeSpan.TicksPerMinute * 10)
                    : new TimeSpan(preflightMaxAgeTicks);

                //来源判断规则
                bool isOriginAllowed(string origin)
                {
                    var isAllowed = originList
                    .Any(item => origin
                        .ToLower()
                        .Contains(item)
                     );

                    return isAllowed;
                };

                //配置规则
                t.AllowAnyHeader()//对应Access-Control-Expose-Headers
                .AllowAnyMethod()//对应Access-Control-Allow-Methods
                .SetPreflightMaxAge(time)//对应Access-Control-Max-Age
                .SetIsOriginAllowed(isOriginAllowed);//对应Access-Control-Allow-Origin
            });

            return builder;
        }

        ////这个方法是以前使用的配置CORS服务的方法
        ///// <summary>
        ///// 注册跨域服务，允许所有跨域
        ///// </summary>
        ///// <param name="services"></param>
        ///// <returns></returns>
        //public static IServiceCollection AddAllowCORSMPS(this IServiceCollection services)
        //{
        //    services.AddCors(options =>
        //    {
        //        options.AddPolicy("AllowAnyOrigin",builder =>
        //       {
        //           builder.WithOrigins("*.newegg.org","*.newegg.com")
        //                  .AllowAnyMethod()
        //                  .AllowAnyHeader()

        //                  ;
        //       });
        //    });

        //    services.Configure<MvcOptions>(options =>
        //    {
        //        options.Filters.Add(new CorsAuthorizationFilterFactory("AllowAnyOrigin"));
        //    });

        //    return services;
        //}
    }
}