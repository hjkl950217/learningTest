﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MvcCoreMPSMiddleware.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MvcCoreMPSMiddleware created at  2018-04-10 星期二 09:54:07
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Newtonsoft.Json;
using System;
using System.Reflection;

namespace Mkpl.Sdk.Core
{
    public static class MvcCoreMpsExtension
    {
        /// <summary>
        /// 注册路由、MVC和对应的服务配置
        /// </summary>
        /// <param name="services">IServiceCollection实例</param>
        /// <param name="setup">Setup类实例，一般在Setup类中使用传this即可</param>
        public static void AddMvcCoreMPS(
            this IServiceCollection services,
            object setup)
        {
            if (services == null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            //配置路由匹配忽略大小写
            services.AddRouting(options =>
            {
                options.LowercaseUrls = true;
            });

            #region 配置MvcCore

            //PS：#endregion的附近有';'来结束mvc的配置
            services.AddMvcCore(opt =>
            {
                //添加绑定模型时的验证
                opt.Filters.Add<MpsValidationFilter>();
            })

            //添加APIExplorer
           .AddApiExplorer()

           //配置Json序列化
           .AddJsonOptions(options =>
           {
               //把解析器设置为Newtonsoft.Json
               options.SerializerSettings.ContractResolver =
                      new Newtonsoft.Json.Serialization.DefaultContractResolver();

               //设置Newtonsoft.Json.JsonSerializer的引用循环处理选项。
               options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;

               //设置缩进
               options.SerializerSettings.Formatting = Formatting.Indented;

               //使用Newtonsoft.Json里的enum转换器
               options.SerializerSettings.Converters.Add(new Newtonsoft.Json.Converters.StringEnumConverter());

               //忽略空值
               //options.SerializerSettings.NullValueHandling = Newtonsoft.Json.NullValueHandling.Ignore;
           })
           .AddJsonFormatters()

           //添加CORS服务
           .AddCors()

            //添加请求参数验证器-注册webapi程序集的所有验证规则
           .AddFluentValidation(fv =>
           {
               //这里setup实例对应的程序集才是webapi那个程序集
               //所以这样取才能取到最正确的
               fv.RegisterValidatorsFromAssembly(Assembly.GetAssembly(setup.GetType()));

               //兼容ASP.NET的内置验证
               // fv.RunDefaultMvcValidationAfterFluentValidationExecutes = true;
           })

            // .AddFormatterMappings()

            ;

            #endregion 配置MvcCore

            //配置HTTP上下文访问器
            services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();
        }
    }
}