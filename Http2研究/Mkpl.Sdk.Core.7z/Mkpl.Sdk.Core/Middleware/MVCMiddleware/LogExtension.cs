﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newegg.MIS.Baymax.Log;

namespace Mkpl.Sdk.Core
{
    public static class LogExtension
    {
        /// <summary>
        /// 配置-MPS组的日志
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddLogMps(this IServiceCollection services)
        {
            //配置日志等级
            services.AddLogging(log =>
            {
                //只记录 Error / Warning / Critical 三个级别的
                log.AddFilter((level) =>
                {
                    return level == LogLevel.Error
                        || level == LogLevel.Warning
                        || level == LogLevel.Critical;
                });
            });

            // 添加 bts log 功能 
            services.TryAddSingletonService<ILog, LogClient>();
            services.AddSingleton<ILoggerProvider, NeweggLoggerProvider>();

            return services;
        }
    }
}