﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IMQClient.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   IMQClient created at  5/12/2018 10:50:08 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.Baymax.MQ;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// MPS组-MQ客户端
    /// </summary>
    public interface IMQClient
    {
        ///// <summary>
        ///// 发送JSON消息
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="message"></param>
        ///// <param name="queueKeyConst">queue在程序中的常量key</param>
        ///// <param name="header"></param>
        ///// <remarks>
        ///// queue的key不一定要在QueueKeyConst类中，只要在Config service上有就行
        ///// </remarks>
        ///// <returns></returns>
        //bool SendMessage<T>(T message, string queueKeyConst, MQHeader header) where T : class;

        ///// <summary>
        ///// 发送JSON消息
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="message"></param>
        ///// <param name="queueKeyConst">queue在程序中的常量key</param>
        ///// <param name="header"></param>
        ///// <remarks>
        ///// queue的key不一定要在QueueKeyConst类中，只要在Config service上有就行
        ///// </remarks>
        ///// <returns></returns>
        //Guid SendMessageGuid<T>(T message, string queueKeyConst, MQHeader header) where T : class;

        /// <summary>
        /// 发送JSON消息
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="message"></param>
        /// <param name="queueKeyConst">queue在程序中的常量key</param>
        /// <param name="header"></param>
        /// <remarks>
        /// queue的key不一定要在QueueKeyConst类中，只要在Config service上有就行
        /// </remarks>
        /// <returns></returns>
        PublishResultInfo SendMessage<T>(T message, string queueKeyConst, MQHeader header) where T : class;
    }
}