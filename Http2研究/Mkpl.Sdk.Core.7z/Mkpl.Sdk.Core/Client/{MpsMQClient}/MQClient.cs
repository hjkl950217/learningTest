﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MQClient.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MQClient created at  5/12/2018 10:50:36 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.Baymax.MQ;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// The class of MQClient.
    /// </summary>
    public class MQClient : IMQClient
    {
        /// <summary>
        /// MQ配置-ConfigService
        /// </summary>
        private readonly GroupQueue groupQueue;

        /// <summary>
        /// MQ发送接口
        /// </summary>
        private readonly IMessagePublisher messagePublisher;

        public MQClient(MQConfig mQConfig, IMessagePublisher messagePublisher)
        {
            this.groupQueue = mQConfig.GroupQueues
                  .FirstOrDefault(t => t.GoupName == QueueGoupNameConst.Team_MKPL);
            this.messagePublisher = messagePublisher;

            if (this.groupQueue == null)
            {
                throw new InvalidOperationException($"GroupQueue Config is not found,Group Key:{QueueGoupNameConst.Team_MKPL}");
            }
        }

        ///// <summary>
        ///// 发送JSON消息
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="message"></param>
        ///// <param name="queueKeyConst">queue在程序中的常量key</param>
        ///// <param name="header"></param>
        ///// <remarks>
        ///// queue的key不一定要在QueueKeyConst类中，只要在Config service上有就行
        ///// </remarks>
        ///// <returns></returns>
        //public bool SendMessage<T>(T message, string queueKeyConst, MQHeader header)
        //    where T : class
        //{
        //    //发送
        //    PublishResultInfo result = this.BaseSend<T>(
        //        message,
        //        queueKeyConst,
        //        header);

        //    return result.IsSucceed;
        //}

        ///// <summary>
        ///// 发送JSON消息
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="message"></param>
        ///// <param name="queueKeyConst">queue在程序中的常量key</param>
        ///// <param name="header"></param>
        ///// <remarks>
        ///// queue的key不一定要在QueueKeyConst类中，只要在Config service上有就行
        ///// </remarks>
        ///// <returns>返回成功的GUID数据，不成功的都抛出异常</returns>
        //public Guid SendMessageGuid<T>(T message, string queueKeyConst, MQHeader header)
        //    where T : class
        //{
        //    //发送
        //    PublishResultInfo result = this.BaseSend<T>(
        //        message,
        //        queueKeyConst,
        //        header);

        //    return result.MessageId;
        //}

        /// <summary>
        /// 基础发送方法
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="message"></param>
        /// <param name="queueKeyConst"></param>
        /// <param name="header"></param>
        /// <returns></returns>
        public virtual PublishResultInfo SendMessage<T>(T message, string queueKeyConst, MQHeader header)
               where T : class
        {
            if (header == null)
            {
                throw new ArgumentNullException(nameof(header), "The parameter ' header' cannot be empty when sending MQ");
            }

            if (message.IsNullOrEmpty() == true)
            {
                throw new ArgumentNullException(nameof(message), "The parameter ' message' cannot be empty when sending MQ");
            }

            Queue queue = this.groupQueue.FindQueue(queueKeyConst);
            List<KeyValuePair<string, string>> headerList = header.CreteHeaderList(queue.KeyName);

            //发送
            PublishResultInfo result = this.messagePublisher.SendMessage(
                message,
                queue.QueueName,
                contentType: MessageContentType.Json,
                password: queue.Password,
                headers: headerList
                );

            ////处理异常情况
            //if(result == null)
            //{
            //    throw new DataException($"MQ Send Failed.publishResult is null.");
            //}
            //if(result.IsSucceed == false)
            //{
            //    throw new DataException($"MQ Send Failed.ErrorCode:{result.ErrorCode},ErrorMessage:{result.ErrorMessage}, QueueKeyName:{queue.KeyName}");
            //}

            return result;
        }
    }
}