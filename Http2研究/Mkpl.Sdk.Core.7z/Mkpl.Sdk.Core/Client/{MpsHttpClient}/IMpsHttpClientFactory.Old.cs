﻿using System;

namespace Mkpl.Sdk.Core.Client
{
    public partial interface IMpsHttpClientFactory
    {
        /// <summary>
        /// (已弃用)获取普通请求客户端.<para></para>
        /// 推荐使用<see cref="GetRestClient(Entities.ConstOrEnum.TeamNameEnum)"/>
        /// </summary>
        /// <param name="teamNameKey">团队名，注意大小写</param>
        /// <returns></returns>
        [Obsolete("请参考说明使用新方法")]
        IMpsHttpClient GetRestClient(string teamNameKey);

        /// <summary>
        /// (已弃用)获取OAuth请求客户端<para></para>
        /// 推荐使用<see cref="GetOAuthClient(Entities.ConstOrEnum.TeamNameEnum)"/>
        /// </summary>
        /// <param name="teamNameKey">团队名，注意大小写</param>
        /// <returns></returns>
        [Obsolete("请参考说明使用新方法")]
        IMpsHttpClient GetOAuthClient(string teamNameKey);
    }
}