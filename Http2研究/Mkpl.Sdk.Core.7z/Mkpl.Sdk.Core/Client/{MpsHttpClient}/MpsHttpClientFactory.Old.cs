﻿using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System;
using System.Linq;

namespace Mkpl.Sdk.Core.Client
{
    public partial class MpsHttpClientFactory
    {
        //此文件代表旧设计，以后可能被删除掉

        #region 内部方法

        /// <summary>
        /// 按不同的类型构建不同的客户端
        /// </summary>
        /// <param name="teamNameKey">团队名</param>
        /// <param name="httpClientTypeEnum">客户端类型</param>
        /// <returns></returns>
        protected virtual IMpsHttpClient BaseBuild(
            string teamNameKey,
            HttpClientTypeEnum httpClientTypeEnum)
        {
            bool isExist = this.otherTeamConfig.TeamApiConfigList.Keys
                .Any(t => t.EqualsLoose(teamNameKey) == true);
            if (isExist == false)
            {
                throw new ArgumentException($"key not found in '{nameof(AllApiConfig)}.TeamApiConfigList'  key: {teamNameKey}");
            }

            #region 按不同类型返回

            string devHost = this.otherTeamConfig.DevPlatformHost;
            TeamConfigEntity configEntity = this.otherTeamConfig.TeamApiConfigList
                .First(t => t.Key.EqualsLoose(teamNameKey) == true)
                .Value;

            switch (httpClientTypeEnum)
            {
                case HttpClientTypeEnum.MpsRest:
                    return new RestClient(this.clientFactory, devHost, configEntity);

                case HttpClientTypeEnum.MpsOAuth:
                    return new OAuthClient(this.clientFactory, devHost, configEntity);

                default:
                    throw new InvalidOperationException($"Invalid Operation for BuildMpsHttpClient,Error Type:{httpClientTypeEnum.ToString()}");
            }

            #endregion 按不同类型返回
        }

        /// <summary>
        /// 检查客户端是否存在,如果存在则直接返回
        /// </summary>
        /// <param name="teamNameKey">团队名，不存在时创建使用</param>
        /// <param name="httpClientType">客户端类型，不存在时创建使用</param>
        /// <returns></returns>
        protected virtual IMpsHttpClient RepeatCheckOrGet(
            string teamNameKey,
            HttpClientTypeEnum httpClientType)
        {
            string clientKey = $"{httpClientType}{teamNameKey}";

            IMpsHttpClient result = this.OldClient
                .GetOrAdd(clientKey, t =>
                {
                    return this.BaseBuild(teamNameKey, httpClientType);
                });

            return result;
        }

        #endregion 内部方法

        /// <summary>
        /// (已弃用)获取普通请求客户端.推荐使<see cref="GetOAuthClient(TeamNameEnum)"/>
        /// </summary>
        /// <param name="teamNameKey">请使用<see cref="TeamNameConst"/>中的常量</param>
        /// <returns></returns>
        public IMpsHttpClient GetOAuthClient(string teamNameKey)
        {
            return this.RepeatCheckOrGet(teamNameKey, HttpClientTypeEnum.MpsOAuth);
        }

        /// <summary>
        ///(已弃用) 获取OAuth请求客户端.推荐使<see cref="GetRestClient(TeamNameEnum)"/>
        /// </summary>
        /// <param name="teamNameKey">请使用<see cref="TeamNameConst"/>中的常量</param>
        /// <returns></returns>
        public IMpsHttpClient GetRestClient(string teamNameKey)
        {
            return this.RepeatCheckOrGet(teamNameKey, HttpClientTypeEnum.MpsRest);
        }
    }
}