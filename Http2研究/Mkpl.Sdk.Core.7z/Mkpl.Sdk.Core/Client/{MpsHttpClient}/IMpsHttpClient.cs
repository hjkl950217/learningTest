﻿using Mkpl.Sdk.Core.Entities;
using System.IO;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// MPS-http客户端接口，请通过IMpsHttpClientFactory接口创建
    /// </summary>
    public partial interface IMpsHttpClient
    {
        #region 其它方法

        /// <summary>
        /// 获取一个默认的请求头对象
        /// </summary>
        /// <param name="accept"></param>
        /// <returns></returns>
        RequestHead GetDefaultHead(string accept = null);

        #endregion 其它方法

        #region GET

        /// <summary>
        /// 发送GET请求
        /// </summary>
        /// <typeparam name="TResult">返回数据要被序列化的类型</typeparam>
        /// <param name="apiKey">团队节点中配置的apiKey</param>.
        /// <param name="queryData">?号后面的数据</param>
        /// <param name="requestHead">
        /// 请求头数据
        /// <para>请求的接口有特殊要求再传</para>
        /// </param>
        /// <param name="queryStrList">格式化数据，会替换掉url中的{0}这种占位符</param>
        /// <returns></returns>
        TResult Get<TResult>(
            string apiKey,
            object queryData = null,
            RequestHead requestHead = null,
            params object[] queryStrList);

        /// <summary>
        /// 发送GET异步请求
        /// </summary>
        /// <typeparam name="TResult">返回数据要被序列化的类型</typeparam>
        /// <param name="apiKey">团队节点中配置的apiKey</param>.
        /// <param name="queryData">?号后面的数据</param>
        /// <param name="requestHead">
        /// 请求头数据
        /// <para>请求的接口有特殊要求再传</para>
        /// </param>
        /// <param name="queryStrList">格式化数据，会替换掉url中的{0}这种占位符</param>
        /// <returns></returns>
        Task<TResult> GetAsync<TResult>(
            string apiKey,
            object queryData = null,
            RequestHead requestHead = null,
            params object[] queryStrList);

        /// <summary>
        /// 发送GET异步请求,获取文件流
        /// </summary>
        /// <param name="apiKey">团队节点中配置的apiKey</param>
        /// <param name="requestHead">
        /// 请求头数据
        /// <para>以流方式请求时请传递指定Accept的RequestHead对象</para>
        /// </param>
        /// <param name="queryData">?号后面的数据</param>
        /// <param name="queryStrList">格式化数据，会替换掉url中的{0}这种占位符</param>
        /// <returns>http中的响应流</returns>
        Task<Stream> GetStreamAsync(
           string apiKey,
           RequestHead requestHead,
           object queryData = null,
           params object[] queryStrList);

        #endregion GET

        #region POST

        /// <summary>
        /// 发送Post请求
        /// </summary>
        /// <typeparam name="TResult">返回数据要被序列化的类型</typeparam>
        /// <param name="apiKey">团队节点中配置的apiKey</param>
        /// <param name="requestData">请求的数据</param>
        /// <param name="requestHead">
        /// 请求头数据
        /// <para>请求的接口有特殊要求再传</para>
        /// </param>
        /// <param name="queryStrList">格式化数据，会替换掉url中的{0}这种占位符</param>
        /// <returns></returns>
        TResult Post<TResult>(
            string apiKey,
            object requestData,
            RequestHead requestHead = null,
            params object[] queryStrList);

        /// <summary>
        /// 发送Post异步请求
        /// </summary>
        /// <typeparam name="TResult">返回数据要被序列化的类型</typeparam>
        /// <param name="apiKey">团队节点中配置的apiKey</param>
        /// <param name="requestData">请求的数据</param>
        /// <param name="requestHead">
        /// 请求头数据
        /// <para>请求的接口有特殊要求再传</para>
        /// </param>
        /// <param name="queryStrList">格式化数据，会替换掉url中的{0}这种占位符</param>
        /// <returns></returns>
        Task<TResult> PostAsync<TResult>(
            string apiKey,
            object requestData,
            RequestHead requestHead = null,
            params object[] queryStrList);

        /// <summary>
        /// 发送POST异步请求,获取文件流
        /// </summary>
        /// <param name="apiKey">团队节点中配置的apiKey</param>
        /// <param name="requestHead">
        /// 请求头数据
        /// <para>以流方式请求时请传递指定Accept的RequestHead对象</para>
        /// </param>
        /// <param name="requestData">请求的数据</param>
        /// <param name="queryStrList">格式化数据，会替换掉url中的{0}这种占位符</param>
        /// <returns>http中的响应流</returns>
        Task<Stream> PostStreamAsync(
           string apiKey,
           RequestHead requestHead,
           object queryData = null,
           params object[] queryStrList);

        #endregion POST
    }
}