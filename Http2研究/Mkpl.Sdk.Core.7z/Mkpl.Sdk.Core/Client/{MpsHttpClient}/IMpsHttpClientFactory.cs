﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MpsHttpClient.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MpsHttpClient created at  4/28/2018 3:09:11 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities.ConstOrEnum;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// MPS-HttpClient工厂接口
    /// </summary>
    public partial interface IMpsHttpClientFactory
    {
        /// <summary>
        /// 获取普通请求客户端
        /// </summary>
        /// <param name="teamNameKey">团队名枚举。参考<see cref="TeamNameEnum"/></param>
        /// <returns></returns>
        IMpsHttpClient GetRestClient(TeamNameEnum teamNameKey);

        /// <summary>
        /// 获取OAuth请求客户端
        /// </summary>
        /// <param name="teamNameKey">团队名枚举。参考<see cref="TeamNameEnum"/></param>
        /// <returns></returns>
        IMpsHttpClient GetOAuthClient(TeamNameEnum teamNameKey);
    }
}