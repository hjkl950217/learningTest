﻿using Mkpl.Sdk.Core.Entities;

namespace Mkpl.Sdk.Core.Client
{
    public interface IDownConfig
    {
        /// <summary>
        /// 获取DFIS文件下载的配置
        /// </summary>
        /// <param name="key">上传配置中对应的key</param>
        /// <remarks>
        /// 关于key:
        /// <para> key用来标示，配置在ConfigService上的具体配置。</para>
        /// <para>DFIS：MKPL_Common/File_Config下的DFIS节点，key对应GroupInfoList中的name</para>
        /// </remarks>
        /// <returns></returns>
        DfisFileConfigEntity GetDfisDownConfig(string key);
    }
}