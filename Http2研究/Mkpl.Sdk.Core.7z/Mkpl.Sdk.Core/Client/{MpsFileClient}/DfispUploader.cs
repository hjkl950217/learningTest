﻿using Newegg.DFIS.Uploader;
using System.IO;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// dfis上传文件接口（代理接口）
    /// </summary>
    /// <remarks>
    /// Newegg.DFIS.Uploader.HttpUploader的代理版<para></para>
    /// 因为在编写时Dfis.Uploader.Core是静态方法，无法模拟返回。
    /// 所以为了方便单元测试，用一个接口代理下。实现类其实就是调用HttpUploader里面的方法
    /// </remarks>
    public class DfispUploader : IDfispUploader
    {
        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="postedStrem"></param>
        /// <param name="filename"></param>
        /// <param name="uploadURL"></param>
        /// <param name="fileGroup"></param>
        /// <param name="fileType"></param>
        /// <param name="specialPath"></param>
        /// <param name="method"></param>
        public void UploadFile(Stream postedStrem, string filename, string uploadURL, string fileGroup, string fileType, string specialPath, UploadMethod method)
        {
            HttpUploader.UploadFile(
                    postedStrem,
                    filename,
                    uploadURL,
                    fileGroup,
                    fileType,
                    specialPath,
                    UploadMethod.Add);
        }
    }
}