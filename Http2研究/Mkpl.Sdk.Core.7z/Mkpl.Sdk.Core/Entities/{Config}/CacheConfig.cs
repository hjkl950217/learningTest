﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CacheConfig.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   CacheConfig created at  5/8/2018 10:41:58 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Newegg.MIS.EggKeeper.Sdk.Default;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 缓存配置，key是自定义，value是对应的时间，以分钟为单位
    /// </summary>
    /// <remarks>
    /// 位于Config Service 的 MKPL_Common/Cache_Config  下面
    /// </remarks>
    [JsonEgg(ConfigName = "Cache_Config")]
    public class CacheConfig
    {
        /// <summary>
        /// Nair缓存列表，key是团队或微服务名，value是对应的时间，以分钟为单位
        /// </summary>
        public Dictionary<string, int> NairConfigList { get; set; }
    }
}