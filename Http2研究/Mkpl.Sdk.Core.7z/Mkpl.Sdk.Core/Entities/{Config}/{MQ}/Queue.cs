﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Queue.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   Queue created at  5/12/2018 2:10:11 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 消息配置实体
    /// </summary>
    public class Queue
    {
        /// <summary>
        /// Key名，不一定和QueueName相同
        /// </summary>
        public string KeyName { get; set; }

        /// <summary>
        /// Queue名，发送MQ时，需要传递的Key名
        /// </summary>
        public string QueueName { get; set; }

        /// <summary>
        /// 密码，没有单独配置时，取的是MQ组上的默认密码
        /// </summary>
        public string Password { get; set; }
    }
}