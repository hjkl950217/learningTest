﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="GroupqueueExtension.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   GroupqueueExtension created at  5/12/2018 2:09:18 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using System;
using System.Linq;

namespace Mkpl.Sdk.Core.Entities
{
    public static class GroupQueueExtension
    {
        /// <summary>
        /// 查找queue实体，会自动补充密码
        /// </summary>
        /// <param name="groupQueue"></param>
        /// <param name="queueKey">配置中的KeyName</param>
        /// <returns></returns>
        public static Queue FindQueue(this GroupQueue groupQueue, string queueKey)
        {
            Queue result = groupQueue.Queues
                .FirstOrDefault(t => t.KeyName.Equals(queueKey, StringComparison.OrdinalIgnoreCase));

            if (result == null)
            {
                throw new InvalidOperationException($"Queue Config is not found,Queue Key:{queueKey}");
            }

            result.Password = result.Password.IsNullOrEmpty() == true
                ? groupQueue.DefaultPassword
                : result.Password;

            return result;
        }
    }
}