﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="GroupQueue.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   GroupQueue created at  5/12/2018 2:11:48 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// MQ组实体
    /// </summary>
    /// <remarks>
    /// 暂时只有MKPL
    /// </remarks>
    public class GroupQueue
    {
        /// <summary>
        /// 组名
        /// </summary>
        /// <remarks>
        /// 设计时，这个属性是给以后预留的。如果需要向其它团队的MQ通道中发送数据。这个字段马上就能用了。
        /// </remarks>
        public string GoupName { get; set; }

        /// <summary>
        /// 默认密码
        /// </summary>
        public string DefaultPassword { get; set; }

        /// <summary>
        /// Queue的集合
        /// </summary>
        public List<Queue> Queues { get; set; }
    }
}