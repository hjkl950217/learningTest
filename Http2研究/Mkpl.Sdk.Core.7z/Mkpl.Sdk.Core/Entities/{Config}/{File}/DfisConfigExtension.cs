﻿using System;
using System.Linq;

namespace Mkpl.Sdk.Core.Entities
{
    public static class DfisConfigExtension
    {
        public static DfisFileConfigEntity FindDfisConfigInfo(
            this DfisConfig dfisConfig,
            string key)
        {
            #region 异常处理

            if (key.IsNullOrEmpty() == true)
            {
                throw new ArgumentNullException(nameof(key), $"Date is null for {nameof(DfisConfig)},Please check Config Service MKPL_Common-{nameof(FileConfig)},{nameof(FileConfig.Dfis)}{nameof(DfisConfig.GroupInfoList)}.Name:{key}");
            }

            DfisConfigInfo config = dfisConfig.GroupInfoList.FirstOrDefault(t => t.Name == key);
            if (config == null)
            {
                throw new ArgumentException($"Find Data failure for {nameof(DfisConfig.GroupInfoList)},Please check Config Service MKPL_Common-{nameof(FileConfig)},{nameof(FileConfig.Dfis)}{nameof(DfisConfig.GroupInfoList)}.Name:{key}", nameof(key));
            }

            #endregion 异常处理

            DfisFileConfigEntity configEntity = new DfisFileConfigEntity()
            {
                UploadHostAddress = dfisConfig.UploadHostAddress,
                DownloadHostAddress = dfisConfig.DownloadHostAddress,
                Group = config.Group,
                Name = key,
                Type = config.Type
            };

            return configEntity;
        }
    }
}