﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="OtherTeamConfigEntityExtension.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   OtherTeamConfigEntityExtension created at  4/28/2018 1:28:42 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using System;

namespace Mkpl.Sdk.Core.Entities
{
    public static class TeamConfigEntityExtension
    {
        /// <summary>
        /// 查找API数据，api信息中没有配置Host与token时，会取对应团队中的基础数据
        /// </summary>
        /// <param name="configEntity">团队节点</param>
        /// <param name="apiName">团队节点中的api信息key</param>
        /// <param name="DevPlatformHost">Newegg开发者平台的API请求地址</param>
        /// <returns></returns>
        public static ApiEntity FindApi(
            this TeamConfigEntity configEntity,
            string apiName,
            string DevPlatformHost)
        {
            #region 异常处理

            if (apiName.IsNullOrEmpty() == true)
            {
                throw new ArgumentNullException(nameof(apiName), $"Data is null for ApiKey," + BuildErrorString(apiName));
            }

            bool notExist = configEntity.ApiConfigList.ContainsKey(apiName);
            if (notExist == false)
            {
                throw new ArgumentException($"Find Data failure for {nameof(TeamConfigEntity.ApiConfigList)}," + BuildErrorString(apiName), nameof(apiName));
            }

            #endregion 异常处理

            ApiEntity apiInfo = configEntity.ApiConfigList[apiName];

            apiInfo.Host = apiInfo.Host ?? DevPlatformHost;
            apiInfo.Token = apiInfo.Token ?? configEntity.BaseToken;

            return apiInfo;
        }

        private static string BuildErrorString(string apiName)
        {
            return $"Please check Config Service MKPL_Common-{nameof(AllApiConfig)},ApiKey:{apiName}";
        }
    }
}