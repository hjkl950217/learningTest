﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="OtherTeamConfig.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   OtherTeamConfig created at  4/28/2018 11:04:19 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Newegg.MIS.EggKeeper.Sdk.Default;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 对其他团队API引用的数据
    /// </summary>
    /// <remarks>
    /// 位于Config Service上的MKPL_Common下的AllAPIConfig节点
    /// </remarks>
    [JsonEgg(ConfigName = "AllAPIConfig")]
    public class AllApiConfig
    {
        /// <summary>
        /// DeveloperPlatform上的API地址
        /// </summary>
        /// <remarks>
        /// 只有在团队中的BaseHost取不到时使用这个地址
        /// </remarks>
        public string DevPlatformHost { get; set; }

        /// <summary>
        /// 其他团队api数据集合
        /// </summary>
        public Dictionary<string, TeamConfigEntity> TeamApiConfigList { get; set; }
    }
}