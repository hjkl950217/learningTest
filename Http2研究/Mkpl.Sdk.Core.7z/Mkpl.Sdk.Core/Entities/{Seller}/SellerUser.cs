﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// Seller账户信息
    /// </summary>
    public class SellerUser
    {
        /// <summary>
        /// 客户编号，登录后就会有这个
        /// </summary>
        public int CustomerNumber { get; set; }

        /// <summary>
        /// 卖家ID，如BHD6
        /// </summary>
        public string SellerID { get; set; }

        /// <summary>
        /// 账户邮件地址
        /// </summary>
        public string UserEmailAddress { get; set; }

        /// <summary>
        /// 用户ID
        /// </summary>
        /// <remarks>
        /// 认证中间件目前在使用这个属性，为了自动化测试API时，中间件能写入数据
        /// </remarks>
        public int UserID { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 账户状态-是否禁一类的
        /// </summary>
        public UserStatusEnum UserStatus { get; set; }

        /// <summary>
        /// 标识内部卖家还是外部卖家
        /// </summary>
        public UserTypeEnum UserType { get; set; }

        public SellerStatusEnum SellerStatus { get; set; }
    }
}