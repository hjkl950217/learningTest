﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="UserCache.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   UserCache created at  4/17/2018 9:52:43 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 登录成功之后，需要存在缓存中的数据模型
    /// </summary>
    /// <remarks>
    /// 用户打开登录页面时请求Authentication项目的登录接口，登录成功之后会由Authentication服务把认证需要的数据写入到Nair
    /// </remarks>
    public class UserCache
    {
        /// <summary>
        /// 用户ID，一般不会使用
        /// </summary>
        public int UserID { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 客户编号，登录后就会有这个
        /// </summary>
        public int CustomerNumber { get; set; }

        /// <summary>
        /// 账户邮件地址，也就是登录名
        /// </summary>
        public string UserEmailAddress { get; set; }

        /// <summary>
        /// 卖家ID，如BHD6
        /// </summary>
        public string SellerID { get; set; }

        /// <summary>
        /// Seller账户状态
        /// </summary>
        public SellerStatusEnum SellerStatus { get; set; }

        /// <summary>
        /// User 状态
        /// </summary>
        public UserStatusEnum UserStatus { get; set; }

        /// <summary>
        /// 三位国家代码，如"USA"
        /// </summary>
        public string CountryCode { get; set; }

        #region 数据模型以外的数据

        /// <summary>
        /// IPV4的地址
        /// </summary>
        public string IPV4Address { get; set; }

        /// <summary>
        /// 菜单功能点
        /// </summary>
        public List<FunctionPointModel> FunctionPointList { get; set; }

        #endregion 数据模型以外的数据
    }
}