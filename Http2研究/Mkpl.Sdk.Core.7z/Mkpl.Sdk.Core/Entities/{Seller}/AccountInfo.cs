﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AccountInfo.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   AccountInfo created at  5/8/2018 2:48:01 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 认证中间件向IOC中写入的数据模型
    /// </summary>
    public class AccountInfo
    {
        /// <summary>
        /// 调用Seller接口得到的卖家基础信息
        /// </summary>
        public SellerBasicInfo SellerBasicInfo { get; set; }

        /// <summary>
        /// 认证完成后写入的用户数据
        /// </summary>
        public UserCache UserCache { get; set; }
    }
}