﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="FunctionPointModel.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   FunctionPointModel created at  5/9/2018 4:37:36 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 功能点实体
    /// </summary>
    public class FunctionPointModel
    {
        /// <summary>
        /// 功能点Id
        /// </summary>
        public int FunctionPointId { get; set; }

        /// <summary>
        /// 功能点名称
        /// </summary>
        public string FunctionPointName { get; set; }

        /// <summary>
        /// 功能点key
        /// </summary>
        public string FunctionPointKey { get; set; }
    }
}