﻿using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// DFIS上传配置的返回实体
    /// </summary>
    public class DfisFileConfigEntity : IFileSoucreType
    {
        /// <summary>
        /// 上传地址
        /// </summary>
        public string UploadHostAddress { get; set; }

        /// <summary>
        /// 下载地址
        /// </summary>
        public string DownloadHostAddress { get; set; }

        /// <summary>
        /// 配置组中的key，标识是那一个配置
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// dfis文件系统中的分组名，MPS通常都是"MPS"
        /// </summary>
        /// <remarks>
        /// DFIS文件系统中，Group相当与一个组申请的大文件夹，type是按业务划分的小文件夹
        /// <para>一般Seller Portal上每个有文件上下载操作的业务都有一个独立的type</para>
        /// </remarks>
        public string Group { get; set; }

        /// <summary>
        /// 业务类型
        /// </summary>
        /// <remarks>
        /// DFIS文件系统中，Group相当与一个组申请的大文件夹，type是按业务划分的小文件夹
        /// <para>一般Seller Portal上每个有文件上下载操作的业务都有一个独立的type</para>
        /// </remarks>
        public string Type { get; set; }

        /// <summary>
        /// 访问前缀
        /// </summary>
        /// <remarks>
        /// 可访问的url前缀，再结合上传后的文件名即可访问
        /// </remarks>
        public string UrlPrefix
        {
            get => this.GetDfisUrlPrefix();
        }

        /// <summary>
        /// 获取数据源类型
        /// </summary>
        /// <returns></returns>
        public FileSoucreTypeEnum GetFileSoucreType()
        {
            return FileSoucreTypeEnum.Dfis;
        }
    }
}