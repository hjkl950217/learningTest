﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 上传文件的返回实体
    /// </summary>
    public class UploadOut
    {
        /// <summary>
        /// 上传时的文件名
        /// </summary>
        public string UploadFileName { get; set; }

        /// <summary>
        /// 上传完成后生成的文件名
        /// </summary>
        /// <example>
        /// eg: AAAA_096ECCA86D127E82.jpeg
        /// <para>eg2:AAAA_BusinessName_F6A070D57B80B92E.jpeg</para>
        /// <para>eg3:AAAA_BusinessName_Name1_F6A070D57B80B92E.jpeg</para>
        /// </example>
        public string FileName { get; set; }

        /// <summary>
        /// 上传完成后生成的完整文件名(可访问的URL)
        /// </summary>
        /// <example>
        /// eg: http://DownHost:8080/Group1/Type1/AAAA_096ECCA86D127E82.jpeg
        /// <para>eg2:<![CDATA[http://DownHost:8080/Group1/Type1/AAAA_BusinessName_F6A070D57B80B92E.jpeg]]></para>
        /// <para>eg3:<![CDATA[http://DownHost:8080/Group1/Type1/AAAA_BusinessName_Name1_F6A070D57B80B92E.jpeg]]></para>
        /// </example>
        public string FilePath { get; set; }

        /// <summary>
        /// 返回给调用者的信息
        /// </summary>
        /// <remarks>
        /// 一般为发送成功或异常之类的提示信息
        /// </remarks>
        public string Message { get; set; }

        /// <summary>
        /// FilePath中的主机地址。代表DFIS服务的主机地址
        /// </summary>
        public string HostAddress { get; set; }

        /// <summary>
        /// 文件的数据源
        /// </summary>
        public FileSoucreTypeEnum SoucreType { get; set; }
    }
}