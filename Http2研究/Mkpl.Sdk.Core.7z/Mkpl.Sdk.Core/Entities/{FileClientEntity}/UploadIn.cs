﻿using Microsoft.AspNetCore.Http;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 上传文件的传入参数
    /// </summary>
    public class UploadIn
    {
        /// <summary>
        /// 要上传的文件相关数据[必须]
        /// </summary>
        /// <remarks>
        /// 文件名请一定要传
        /// </remarks>
        public IFormFile File { get; set; }

        /// <summary>
        /// 卖家编号[必须]
        /// </summary>
        public string SellerID { get; set; }

        /// <summary>
        /// 上传文件的分组名[必须]
        /// </summary>
        /// <remarks>
        /// 以DFIS的上传为例：
        /// <para>在使用他们服务时会申请一个组，代表我们组在他们服务中的大文件夹</para>
        /// </remarks>
        public string GroupName { get; set; }

        /// <summary>
        /// 业务名[可选]
        /// </summary>
        /// <remarks>
        /// 内部存储时是以业务划分的，一般为Seller Portal上每个有文件上下载操作的业务名。
        /// <para>传递后则会在生成文件夹名是带上这个属性</para>
        /// </remarks>
        public string BusinessName { get; set; }

        /// <summary>
        /// [可选]是否在生成的文件中添加ConfigService上的name
        /// </summary>
        /// <remarks>
        /// 这里的name就是取配置用的key，所以用IsAddKey
        /// </remarks>
        public bool IsAddKey { get; set; }
    }
}