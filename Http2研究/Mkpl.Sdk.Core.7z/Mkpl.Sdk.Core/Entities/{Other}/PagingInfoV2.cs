﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System.Xml.Serialization;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 分页信息.相关扩展方法请查看<see cref="PagingInfoHelper"/>
    /// </summary>
    [XmlRoot("PagingInfo")]
    public partial class PagingInfoV2
    {
        /// <summary>
        /// 分页的开始行
        /// </summary>
        /// <remarks>
        /// 比如分页大小是5
        /// <para>第一页传0，返回12345</para>
        /// <para>第一页传5，返回6789 10</para>
        /// </remarks>
        [XmlElement(nameof(PagingInfoV2.StartRowIndex))]
        public int? StartRowIndex { get; set; }

        /// <summary>
        /// 分页大小
        /// </summary>
        [XmlElement(nameof(PagingInfoV2.PageSize))]
        public int? PageSize { get; set; }

        /// <summary>
        /// 用来排序的字段名
        /// </summary>
        [XmlElement(nameof(PagingInfoV2.SortField))]
        public string SortField { get; set; }

        /// <summary>
        /// 排序类型
        /// </summary>
        [XmlElement(nameof(PagingInfoV2.SortType))]
        public SortTypeEnum? SortType { get; set; }
    }
}