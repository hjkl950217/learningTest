﻿using System.Net;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 发生异常时，返回给响应中的数据类型
    /// </summary>
    public class ExceptionOut
    {
        /// <summary>
        /// 响应状态码，一般为错误中的响应码
        /// </summary>
        public string ResponseCode { get; set; }

        /// <summary>
        /// 错误消息
        /// </summary>
        /// <remarks>
        /// PRD需要特殊处理，不能返回实际错误
        /// </remarks>
        public string Message { get; set; }

        /// <summary>
        /// HTTP状态码
        /// </summary>
        public HttpStatusCode StatusCode { get; set; }

        /// <summary>
        /// 调用堆栈
        /// </summary>
        /// <remarks>
        /// PRD需要特殊处理，不返回
        /// </remarks>
        public string StackTrace { get; set; }

        /// <summary>
        /// 请求地址
        /// </summary>
        public string Path { get; set; }
    }
}