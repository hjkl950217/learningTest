﻿namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 业务验证中的元素
    /// </summary>
    public class BizValidationError
    {
        /// <summary>
        /// 自定义状态
        /// </summary>
		public object CustomObject { get; set; }

        /// <summary>
        /// 错误代码
        /// </summary>
        public string ErrorCode { get; set; }

        /// <summary>
        /// 错误消息
        /// </summary>
		public string ErrorMessage { get; set; }
    }
}