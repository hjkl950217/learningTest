﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System.Xml.Linq;

namespace Mkpl.Sdk.Core.Entities
{
    public static class PagingInfoV2Extension
    {
        /// <summary>
        /// 获取<see cref="PagingInfoV2"/>的XML结构。<para></para>
        /// </summary>
        /// <remarks>
        /// 若需要string格式的，请使用<see cref="ObjectExtension.ToXmlExtV2{T}(T, bool)"/>
        /// </remarks>
        /// <returns></returns>
        public static XElement ToXml(this PagingInfoV2 pagingInfoV2)
        {
            XElement pageElement = new XElement("PageInfo");

            var startRowIndex = new XElement(nameof(PagingInfoV2.StartRowIndex), pagingInfoV2.StartRowIndex);
            var pageSize = new XElement(nameof(PagingInfoV2.PageSize), pagingInfoV2.PageSize);
            var sortField = new XElement(nameof(PagingInfoV2.SortField), pagingInfoV2.SortField);
            var sortType = new XElement(nameof(PagingInfoV2.SortType), pagingInfoV2.SortType.ToString());

            pageElement.Add(startRowIndex);
            pageElement.Add(pageSize);
            pageElement.Add(sortField);
            pageElement.Add(sortType);

            return pageElement;
        }
    }

    public partial class PagingInfoV2
    {
        /// <summary>
        /// 获取一个不分页，页面大小无限的分页对象。
        /// <para>通常情况下这种数据适用于要求传递分页字段，但业务上又不分页的时候。</para>
        /// </summary>
        public static PagingInfoV2 GetNonPaging()
        {
            return new PagingInfoV2
            {
                StartRowIndex = 0,
                PageSize = int.MaxValue,
                SortType = SortTypeEnum.ASC
            };
        }

        /// <summary>
        /// 返回一个默认大小的分页对象。<para></para>
        /// 默认大小参见<see cref="PagingInfoConst.PageSize_Default"/>
        /// </summary>
        public static PagingInfoV2 GetDefaultPaging()
        {
            return new PagingInfoV2
            {
                StartRowIndex = 0,
                PageSize = PagingInfoConst.PageSize_Default,
                SortType = SortTypeEnum.ASC
            };
        }
    }
}