﻿using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 业务验证结果
    /// </summary>
    public class BizValidatorResult
    {
        /// <summary>
        /// 错误消息集合
        /// </summary>
		public IList<BizValidationError> Errors { get; set; } = new List<BizValidationError>();

        /// <summary>
        /// 业务验证是否成功
        /// </summary>
		public bool IsValid { get; set; }
    }
}