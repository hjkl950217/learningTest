﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MQHeaderExtension.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MQHeaderExtension created at  5/12/2018 1:34:48 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using System;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// MQHeader扩展
    /// </summary>
    public static class MQHeaderExtension
    {
        /// <summary>
        /// 创建发送MQ时的KV集合
        /// </summary>
        /// <param name="mqHeader"></param>
        /// <param name="keyName">queue的key名</param>
        /// <returns></returns>
        public static List<KeyValuePair<string, string>> CreteHeaderList(
            this MQHeader mqHeader,
            string keyName)
        {
            if (string.IsNullOrWhiteSpace(keyName))
            {
                throw new ArgumentNullException(nameof(keyName), "MQHeader CreteHeaderList Failed.");
            }
            if (string.IsNullOrWhiteSpace(mqHeader.Action))
            {
                throw new ArgumentNullException(nameof(mqHeader), "MQHeader`s Action is null, CreteHeaderList Failed.");
            }

            string msgType = $"{keyName}_{mqHeader.Action}";

            List<KeyValuePair<string, string>> headerList = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("Sender", MQHeader.Sender),
                new KeyValuePair<string, string>("MsgType",msgType),
                new KeyValuePair<string, string>("Action",mqHeader.Action)
            };

            if (string.IsNullOrWhiteSpace(mqHeader.CountryCode) == false)
            {
                headerList.Add(new KeyValuePair<string, string>("CountryCode", mqHeader.CountryCode));
            }
            if (string.IsNullOrWhiteSpace(mqHeader.SellerID) == false)
            {
                headerList.Add(new KeyValuePair<string, string>("SellerID", mqHeader.SellerID));
            }
            if (string.IsNullOrWhiteSpace(mqHeader.Version) == false)
            {
                headerList.Add(new KeyValuePair<string, string>("Version", mqHeader.Version));
            }

            return headerList;
        }
    }
}