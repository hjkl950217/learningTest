﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MQHeader.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MQHeader created at  5/12/2018 11:23:25 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 发送MQ时的头部数据
    /// </summary>
    /// <remarks>
    /// 老项目中叫MQMessageHeader
    /// </remarks>
    public class MQHeader
    {
        public string Action { get; set; }

        public string CountryCode { get; set; }

        public string SellerID { get; set; }

        public string Version { get; set; }

        /// <summary>
        /// 发送者
        /// </summary>
        /// <remarks>
        /// 微服务也使用"Portal2.0" 标示是那个平台发出
        /// </remarks>
        public const string Sender = "Portal2.0";
    }
}