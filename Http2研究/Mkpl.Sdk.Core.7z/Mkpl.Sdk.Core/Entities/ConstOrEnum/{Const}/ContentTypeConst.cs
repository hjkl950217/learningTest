﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ContentFormat.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   ContentFormat created at  3/7/2018 3:18:25 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// http格式常量.
    /// </summary>
    public static class ContentTypeConst
    {
        /// <summary>
        /// json格式
        /// </summary>
        public const string Json = "application/json";

        /// <summary>
        /// Xml格式
        /// </summary>
        public const string Xml = "application/xml";

        /// <summary>
        /// octet-stream.代表未知格式
        /// </summary>
        public const string OctetStream = "application/octet-stream";

        /// <summary>
        /// 文件流-Excel
        /// </summary>
        public const string Excel = "application/vnd.ms-excel";

        /// <summary>
        /// 序列化协议-MessagePack
        /// <para>非RFC文件规定的值</para>
        /// </summary>
        public const string MessagePack = "application/msgpack";

        /// <summary>
        /// 序列化协议-MessagePack Lz4
        /// <para>非RFC文件规定的值</para>
        /// </summary>
        public const string MessagePackLz4 = "application/msgpack-lz4";
    }
}