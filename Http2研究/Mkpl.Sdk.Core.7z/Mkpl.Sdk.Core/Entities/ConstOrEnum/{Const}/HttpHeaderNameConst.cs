﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="HttpHeaderConst.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   HttpHeaderConst created at  5/10/2018 1:32:24 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 在Http通信中需要的头部名常量
    /// </summary>
    public static class HttpHeaderNameConst
    {
        /// <summary>
        /// MPS组认证中间件使用的头
        /// </summary>
        public const string MpsToken = "Authentication";

        /// <summary>
        /// MPS组老项目-认证中间件使用的头
        /// </summary>
        public const string MpsRestApiToken = "AuthorizationToken";

        /// <summary>
        /// 标准认证头
        /// </summary>
        public const string Authorization = "Authorization";

        /// <summary>
        /// 源IP，通过API网关过来的请求需要用这个头取到真实源IP
        /// </summary>
        public const string XSoucreIP = "X-Source-IP";

        /// <summary>
        /// User-Agent头的名字
        /// </summary>
        public const string UserAgent = "User-Agent";

        /// <summary>
        /// Content-Type头的名字，响应内容的格式
        /// </summary>
        public const string ContentType = "Content-Type";

        /// <summary>
        /// Content-Language头的名字，响应内容的语言
        /// </summary>
        public const string ContentLanguage = "Content-Language";

        /// <summary>
        /// Cache-Control头的名字,缓存控制
        /// </summary>
        public const string CacheControl = "Cache-Control";
    }
}