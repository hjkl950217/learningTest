﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="QueueConst.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   QueueConst created at  5/12/2018 11:11:23 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

namespace Mkpl.Sdk.Core.Entities
{
    public static class QueueGoupNameConst
    {
        /// <summary>
        /// MKPL的Queue组名
        /// </summary>
        public const string Team_MKPL = "MKPL";
    }
}