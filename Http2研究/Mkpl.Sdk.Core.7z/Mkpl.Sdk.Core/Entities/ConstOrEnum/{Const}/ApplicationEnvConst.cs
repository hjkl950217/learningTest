﻿namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 程序环境常量
    /// </summary>
    /// <remarks>GDEV GQC PRE E11这种</remarks>
    public static class ApplicationEnvConst
    {
        /// <summary>
        /// 开发者环境，等同GDEV
        /// </summary>
        public const string Development = "Development";

        /// <summary>
        /// 开发者环境
        /// </summary>
        public const string GDEV = "GDEV";

        /// <summary>
        /// 集成测试环境
        /// </summary>
        public const string GQC = "GQC";

        /// <summary>
        /// 线上E11机房
        /// </summary>
        public const string E11 = "E11";

        /// <summary>
        /// 线上E4机房
        /// </summary>
        public const string E4 = "E4";

        /// <summary>
        /// 产品测试环境
        /// </summary>
        public const string PRE = "PRE";
    }
}