﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SellerTypeEnum.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   SellerTypeEnum created at  5/5/2018 3:56:49 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities.Attribute;

namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 卖家类型
    /// </summary>
    public enum SellerTypeEnum
    {
        /// <summary>
        /// 国内 DB值：D
        /// </summary>
        [EnumDescription(ShowValue: "Domestic", DbValue: "D")]
        Domestic = 68,

        /// <summary>
        /// 国际  DB值：I
        /// </summary>
        [EnumDescription(ShowValue: "International", DbValue: "I")]
        International = 73
    }
}