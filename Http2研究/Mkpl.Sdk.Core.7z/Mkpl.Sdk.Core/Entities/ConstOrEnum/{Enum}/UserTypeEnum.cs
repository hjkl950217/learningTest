﻿using Mkpl.Sdk.Core.Entities.Attribute;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 标示内部卖家还是外部卖家
    /// </summary>
    public enum UserTypeEnum
    {
        /// <summary>
        /// 内部卖家 DB值：I
        /// </summary>
        [EnumDescription(ShowValue: "Internal", DbValue: "I")]
        Internal = 73,

        /// <summary>
        /// 外部卖家 DB值：N
        /// </summary>
        [EnumDescription(ShowValue: "Normal", DbValue: "N")]
        Normal = 78,

        /// <summary>
        /// 老板，卖家中有权创建店小二的那个。<para></para>
        /// DB值：O
        /// </summary>
        [EnumDescription(ShowValue: "Owner", DbValue: "O")]
        Owner = 79
    }
}