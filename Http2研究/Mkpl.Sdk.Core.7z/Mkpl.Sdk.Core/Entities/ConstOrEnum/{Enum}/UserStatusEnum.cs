﻿using Mkpl.Sdk.Core.Entities.Attribute;

namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 账户状态
    /// </summary>
    public enum UserStatusEnum
    {
        /// <summary>
        /// 禁用  DB值：D
        /// </summary>
        [EnumDescription(ShowValue: "Owner", DbValue: "D")]
        Disable = 68,

        /// <summary>
        /// 启用  DB值：E
        /// </summary>
        [EnumDescription(ShowValue: "Enable", DbValue: "E")]
        Enable = 69,

        /// <summary>
        /// 被邀请，代表还没有激活  DB值：I
        /// </summary>
        [EnumDescription(ShowValue: "Invitating", DbValue: "I")]
        Invitating = 73
    }
}