﻿namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 表示文件操作中对应的数据源类型
    /// </summary>
    public enum FileSoucreTypeEnum
    {
        /// <summary>
        /// 数据源为DFIS
        /// </summary>
        Dfis,

        /// <summary>
        /// 数据源为FTP
        /// </summary>
        FTP,
    }
}