﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SellerPaymentTypeEnum.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   SellerPaymentTypeEnum created at  5/5/2018 3:31:17 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities.Attribute;

namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 卖家支付方式
    /// </summary>
    public enum SellerPaymentTypeEnum : int
    {
        [EnumDescription(ShowValue: "ACH", DbValue: "H")]
        ACH = 72,

        [EnumDescription(ShowValue: "Wrietransfer", DbValue: "I")]
        WrieTransfer = 73,

        [EnumDescription(ShowValue: "Payoneer", DbValue: "A")]
        Payoneer = 65,

        [EnumDescription(ShowValue: "WorldFirst", DbValue: "W")]
        WorldFirst = 87,

        [EnumDescription(ShowValue: "Paypal", DbValue: "Y")]
        Paypal = 89,

        [EnumDescription(ShowValue: "PingPong", DbValue: "X")]
        PingPong = 88,

        /// <summary>
        /// 自结算的卖家
        /// </summary>
        /// <remarks>
        /// 一般的卖家：买家先把钱给新蛋，再由新蛋和卖家结算。<para></para>
        /// ISO卖家：买家直接把新给卖家，再由新蛋和卖家结算
        /// </remarks>
        [EnumDescription(ShowValue: "Iso", DbValue: "S")]
        ISO = 83,

        /// <summary>
        /// 预留
        /// </summary>
        [EnumDescription(ShowValue: "Psp", DbValue: "P")]
        PSP = 80,

        /// <summary>
        /// 默认的支付方式
        /// </summary>
        [EnumDescription(ShowValue: "NA", DbValue: "N")]
        NA = 78,
    }
}