﻿using Mkpl.Sdk.Core.Entities.Attribute;

namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 团队名枚举
    /// </summary>
    /// <remarks>
    /// 对其它团队：以团队名<para></para>
    /// 对MPS微服务：以微服务名，当然一个虚拟的小组<para></para>
    /// </remarks>
    public enum TeamNameEnum
    {
        /*
         *
         * 使用EnumDescription的Description属性来描述
         *
         */

        #region CD-其它团队

        /// <summary>
        /// 成都-EC团队名
        /// </summary>
        [EnumDescription(Description: "CdEc")]
        CdEc,

        /// <summary>
        /// 成都-ET团队名
        /// </summary>
        [EnumDescription(Description: "CdEt")]
        CdEt,

        /// <summary>
        /// 成都-ACCT团队名
        /// </summary>
        [EnumDescription(Description: "CdAcct")]
        CdAcct,

        /// <summary>
        /// 成都-BTS团队名
        /// </summary>
        [EnumDescription(Description: "CdBts")]
        CdBts,

        /// <summary>
        /// 成都-OZZO团队名
        /// </summary>
        [EnumDescription(Description: "CdOzzo")]
        CdOzzo,

        /// <summary>
        /// 成都-PO团队名
        /// </summary>
        [EnumDescription(Description: "CdPo")]
        CdPo,

        /// <summary>
        /// 成都-DFIS团队名
        /// </summary>
        [EnumDescription(Description: "CdDfis")]
        CdDfis,

        /// <summary>
        /// 成都-ESB团队名
        /// </summary>
        [EnumDescription(Description: "CdEsb")]
        CdEsb,

        /// <summary>
        /// 成都-DBA团队名
        /// </summary>
        [EnumDescription(Description: "CdDba")]
        CdDba,

        #endregion CD-其它团队

        #region 其它地区团队

        /// <summary>
        /// 台湾-EC团队名
        /// </summary>
        [EnumDescription(Description: "TwEc")]
        TwEc,

        /// <summary>
        /// 上海-EC团队名
        /// </summary>
        [EnumDescription(Description: "ShEc")]
        ShEc,

        /// <summary>
        /// 西安-EC团队名
        /// </summary>
        [EnumDescription(Description: "XaEc")]
        XaEc,

        /// <summary>
        /// 台湾-B2B团队名
        /// </summary>
        [EnumDescription(Description: "TwB2b")]
        TwB2b,

        /// <summary>
        /// 西安-Im团队名
        /// </summary>
        [EnumDescription(Description: "XaIm")]
        XaIm,

        /// <summary>
        /// 台湾-Im团队名
        /// </summary>
        [EnumDescription(Description: "TwIm")]
        TwIm,

        #endregion 其它地区团队

        #region MPS-微服务

        /// <summary>
        /// MPS组-Item微服务名
        /// </summary>
        [EnumDescription(Description: "Item")]
        Item,

        /// <summary>
        /// MPS组-认证微服务名
        /// </summary>
        [EnumDescription(Description: "Authentication")]
        Authentication,

        /// <summary>
        /// MPS组-Seller微服务名
        /// </summary>
        [EnumDescription(Description: "Seller")]
        Seller,

        /// <summary>
        /// MPS组-Order微服务名
        /// </summary>
        [EnumDescription(Description: "Order")]
        Order,

        /// <summary>
        /// MPS组-ApproveCenter微服务名
        /// </summary>
        [EnumDescription(Description: "ApproveCenter")]
        ApproveCenter,

        /// <summary>
        /// MPS组-以前老API项目的名字
        /// </summary>
        [EnumDescription(Description: "RestAPI")]
        RestAPI,

        #endregion MPS-微服务
    }
}