﻿namespace Mkpl.Sdk.Core.Threads
{
    /// <summary>
    /// Make current thread pause for specific ms.
    /// </summary>
    public interface IThreadPauser
    {
        /// <summary>
        /// Sleep for specific ms.
        /// </summary>
        /// <param name="milliSeconds"></param>
        void Sleep(int milliSeconds);
    }
}