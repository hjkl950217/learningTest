﻿using Mkpl.Sdk.Core.Helpers;
using System.Threading;

namespace Mkpl.Sdk.Core.Threads
{
    /// <summary>
    /// The implementation of IThreadPauser
    /// </summary>
    public class ThreadPauser : IThreadPauser
    {
        private ThreadPauser()
        {
        }

        static ThreadPauser()
        {
            InstanceManager.RegisterBuilder<IThreadPauser, ThreadPauser>(
                () => new ThreadPauser());
        }

        /// <summary>
        /// Get the instance of ThreadPauser
        /// </summary>
        public static IThreadPauser Instance
        {
            get { return InstanceManager.GetInstance<IThreadPauser>(); }
        }

        /// <summary>
        /// Sleep for specific ms.
        /// </summary>
        /// <param name="milliSeconds"></param>
        public void Sleep(int milliSeconds)
        {
            Thread.Sleep(milliSeconds);
        }
    }
}