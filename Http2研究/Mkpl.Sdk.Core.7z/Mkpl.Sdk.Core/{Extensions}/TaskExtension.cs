﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="TaskExtension.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   TaskExtension created at  5/8/2018 9:44:17 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using System.Threading.Tasks;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// Task类扩展
    /// </summary>
    public static class TaskExtension
    {
        /// <summary>
        /// 获取同步结果
        /// </summary>
        /// <param name="task">无返回值异步任务</param>
        public static void GetAwaitResult(this Task task)
        {
            task.ConfigureAwait(false)
                .GetAwaiter()
                .GetResult();
        }

        /// <summary>
        /// 获取同步结果
        /// </summary>
        /// <param name="task">有返回值异步任务</param>
        public static TResult GetAwaitResult<TResult>(this Task<TResult> task)
        {
            return task.ConfigureAwait(false)
                .GetAwaiter()
                .GetResult();
        }
    }
}