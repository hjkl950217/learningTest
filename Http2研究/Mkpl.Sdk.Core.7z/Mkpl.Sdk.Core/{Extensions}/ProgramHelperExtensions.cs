﻿using Mkpl.Sdk.Core.Helpers;
using Newegg.MIS.AriesDoc;
using System;

namespace Microsoft.AspNetCore.Hosting
{
    public static class ProgramHelperExtensions
    {
        /// <summary>
        /// 请在ProgramHelper后面运行此方法以启动web应用
        /// </summary>
        /// <typeparam name="TStartup">项目中的Startup类</typeparam>
        /// <param name="programHelper">初始化过的ProgramHelper</param>
        public static void MpsRun<TStartup>(this ProgramHelper<TStartup> programHelper)
            where TStartup : class
        {
            Action action = () =>
            {
                programHelper
                .BuildWebHost()
                .Build()
                .Run(programHelper.Args);
            };

            AriesDocTool.Run(
              typeof(TStartup),
              programHelper.Args,
              action);
        }
    }
}