﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DateTimeExtension.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   DateTimeExtension created at  2/9/2018 6:22:45 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
using System;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// DateTime扩展类
    /// </summary>
    public static class DateTimeExtensions
    {
        /// <summary>
        /// MKPL Cumstom extension metohed: format DateTIme to string as yyyy-MM-ddTHH:mm:ss
        /// </summary>
        /// <param name="source">thre given original DateTime</param>
        /// <returns>the format datetime string</returns>
        public static string ToDateTimeStringExt(this DateTime source)
        {
            return source.ToString("yyyy-MM-ddTHH:mm:ss");
        }

        /// <summary>
        /// MKPL Cumstom extension metohed。
        /// <para>format: yyyy-MM-ddTHH:mm:ss.fffZ</para>
        /// </summary>
        /// <param name="source">thre given original DateTime</param>
        /// <returns>the format datetime string</returns>
        public static string ToSolrDateTimeStringExt(this DateTime source)
        {
            return source.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");
        }

        /// <summary>
        /// MKPL Cumstom extension metohed。
        /// <para>format:MM\\/dd\\/yyyy HH:mm:ss</para>
        /// </summary>
        /// <param name="source">thre given original DateTime</param>
        /// <returns>the format datetime string</returns>
        public static string ToDateTimeStringMpsExt(this DateTime source)
        {
            return source.ToString("MM\\/dd\\/yyyy HH:mm:ss");
        }

        /// <summary>
        /// 转换为Unix时间戳,单位为秒（前端默认是s）
        /// </summary>
        /// <param name="source"></param>
        /// <returns>从1970-01-01T00:00:00.000Z到现在的时间戳</returns>
        public static long ToUnixTimestamp(this DateTime source)
        {
            return DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        }

        /// <summary>
        /// 转换为Unix时间戳,单位为秒（前端默认是s）
        /// </summary>
        /// <param name="source"></param>
        /// <returns>返回格林威治时间,从1970-01-01T00:00:00.000Z到现在的时间戳</returns>
        public static long ToUnixTimestamp(this DateTimeOffset source)
        {
            return source.ToUnixTimeSeconds();
        }
    }
}