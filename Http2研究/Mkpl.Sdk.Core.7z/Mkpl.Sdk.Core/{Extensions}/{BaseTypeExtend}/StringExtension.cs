﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="StringExtension.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   StringExtension created at  2/9/2018 6:17:58 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// 字符串扩展类
    /// </summary>
    public static class StringExtension
    {
        /// <summary>
        ///MKPL Cumstom extension metohed: Auto Convert Json string to object
        /// </summary>
        /// <typeparam name="T">Object Type</typeparam>
        /// <param name="jsonStr">Json String</param>
        /// <returns>Json format string</returns>
        public static T ToObjectExt<T>(this string jsonStr)
        {
            var setting = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore
            };
            var timeConverter = new IsoDateTimeConverter { DateTimeFormat = "MM\\/dd\\/yyyy HH:mm:ss" };
            setting.Converters.Add(timeConverter);

            return JsonConvert.DeserializeObject<T>(jsonStr, setting);
        }

        /// <summary>
        /// MKPL Cumstom extension metohed: if string is not null then trim
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string TrimExt(this string value)
        {
            return (value ?? string.Empty).Trim();
        }

        /// <summary>
        /// 转换成Bool类型
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool ToBoolExt(this string value)
        {
            return (value == null || value == "") ? false : bool.Parse(value);
        }

        /// <summary>
        /// 格式化国家名字，转换成首字母大写，其他小写。如CHINA->China
        /// </summary>
        /// <param name="countryName">国家名字</param>
        /// <returns></returns>
        public static string FormatFullCountryNameExt(this string countryName)
        {
            /* 思路
             * 1.把国家名字按空格分拆成几部分,全小写。比如 ABC  DE F->[abc,de,f]
             * 2.再把每部分的第一个字符变成大写。比如：[Abc,De,F]
             * 3.再把字符串数组装回去。比如："Abc De F"
             */

            if (countryName == null)
            {
                return null;
            }

            List<char[]> countryNameTempList = countryName
                .Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)//分割，去掉空字符串
                .Where(t => t != null && t.Length > 0)//去掉空格字符的情况
                .Select(t => t.ToLower().ToCharArray())
                .ToList();

            StringBuilder sb = new StringBuilder();

            //遍历分割后的字符串，把首字母大写
            for (int i = 0 ; i < countryNameTempList.Count ; i++)//froeach不能给枚举值赋值，所以用for
            {
                countryNameTempList[i][0] = char.ToUpper(countryNameTempList[i][0]);//首字母大写
                sb.Append(countryNameTempList[i]);//添加到缓存变量里
                sb.Append(' ');
            }
            sb.Remove(sb.Length - 1, 1);//移除最后一个多加的空格

            return sb.ToString();
        }

        /// <summary>
        /// ToInt的基础方法
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        private static int ToIntBase(this string str)
        {
            bool isConvert = false;

            isConvert = int.TryParse(str, out int tempInt) || isConvert;//判断可能是int
            if (isConvert == true) return tempInt;

            isConvert = double.TryParse(str, out double tempDouble) || isConvert;//判断可能是double
            if (isConvert == true) return (int)tempDouble;

            isConvert = float.TryParse(str, out float tempfloat) || isConvert;//判断可能是float
            if (isConvert == true) return (int)tempfloat;

            isConvert = decimal.TryParse(str, out decimal tempdecimal) || isConvert;//判断可能是decimal
            if (isConvert == true) return (int)tempdecimal;

            return 0;
        }

        /// <summary>
        /// 转换string为int类型，不能转换时抛异常 兼容int的类型会转换成int
        /// </summary>
        /// <param name="str">需要被转换的string字符串</param>
        /// <returns></returns>
        public static int ToIntExt(this string str)
        {
            if (str.IsNullOrEmpty() == true) throw new ArgumentException("The parameter 'accuracyNum' is invalid data when trying to use 'ToInt' method", nameof(str));

            ToIntBase(str);//使用基础方法检测数据

            return Convert.ToInt32(str);
        }

        /// <summary>
        /// 转换string为int类型，不能转换时默认返回0(不会抛出异常)
        /// </summary>
        /// <param name="str">需要被转换的string字符串</param>
        /// <returns></returns>
        public static int ToIntOrDefaultExt(this string str)
        {
            if (str.IsNullOrEmpty() == true) return 0;
            return ToIntBase(str);
        }

        /// <summary>
        /// ToDecimal的基础方法
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        private static decimal ToDecimalBase(this string str)
        {
            bool isConvert = false;

            isConvert = int.TryParse(str, out int tempInt) || isConvert;//判断可能是int
            if (isConvert == true) return tempInt;

            isConvert = double.TryParse(str, out double tempDouble) || isConvert;//判断可能是double
            if (isConvert == true) return (decimal)tempDouble;

            isConvert = float.TryParse(str, out float tempfloat) || isConvert;//判断可能是float
            if (isConvert == true) return (decimal)tempfloat;

            isConvert = decimal.TryParse(str, out decimal tempdecimal) || isConvert;//判断可能是decimal
            if (isConvert == true) return tempdecimal;

            return 0.0m;
        }

        /// <summary>
        /// string转换为Decimal
        /// </summary>
        /// <param name="str">需要被转换的string字符串</param>
        /// <returns></returns>
        public static decimal ToDecimalExt(this string str)
        {
            if (str.IsNullOrEmpty() == true) throw new ArgumentException("The parameter 'str' is invalid data when trying to use 'ToDecimal' method", nameof(str));

            ToDecimalBase(str);//使用基础方法检测数据

            return Convert.ToDecimal(str);
        }

        /// <summary>
        /// string转换为Decimal,不能转换时返回0.0M
        /// </summary>
        /// <param name="str">需要被转换的string字符串</param>
        /// <param name="accuracyNum">小数位数，默认为1位，不能小于0</param>
        /// <returns></returns>
        public static decimal ToDecimalOrDefaultExt(this string str, int accuracyNum = 1)
        {
            if (accuracyNum < 1) throw new ArgumentException("The parameter 'accuracyNum' is invalid data when trying to use 'ToDecimalOrDefault' method", nameof(accuracyNum));

            if (str.IsNullOrEmpty() == true) return (0.0M).FixExt(accuracyNum);

            return ToDecimalBase(str).FixExt(accuracyNum);
        }

        /// <summary>
        /// string转换为MD5字符串,null或""会返回""
        /// </summary>
        /// <param name="str">要加密的字符串</param>
        /// <param name="is32">是否返回32位长度，为false时返回16位</param>
        /// <returns></returns>
        public static string ToMD5(this string str, bool is32 = true)
        {
            if (str.IsNullOrEmpty() == true) return string.Empty;

            return is32 == true
                ? EncryptionHelper.MD5Encrypt32(str)
                : EncryptionHelper.MD5Encrypt16(str);
        }

        /// <summary>
        /// 判断两个字符串是否相等，忽略大小写
        /// </summary>
        /// <param name="str1"></param>
        /// <param name="str2"></param>
        /// <returns></returns>
        public static bool EqualsIgnoreCase(this string str1, string str2)
        {
            return string.Equals(str1, str2, StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// 判断两个字符串是否相等，忽略大小写，忽略首尾空格
        /// </summary>
        /// <param name="str1"></param>
        /// <param name="str2"></param>
        /// <returns></returns>
        public static bool EqualsLoose(this string str1, string str2)
        {
         
            return string.Equals(str1?.Trim(), str2?.Trim(), StringComparison.OrdinalIgnoreCase);
        }
    }
}