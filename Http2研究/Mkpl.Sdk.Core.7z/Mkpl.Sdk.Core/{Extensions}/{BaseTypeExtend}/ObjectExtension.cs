﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ObjectExtension.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   ObjectExtension created at  3/15/2018 4:08:48 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Newegg.MIS.Baymax.Client.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using ServiceStack;
using System;
using System.Collections;
using System.Text;
using System.Xml;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// The class of ObjectExtension.
    /// </summary>
    public static class ObjectExtension
    {
        /// <summary>
        /// (已弃用)转换成XML字符串。推荐使用<see cref="ToXmlExtV2"/>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <returns></returns>
        [Obsolete("请参考说明使用新方法")]
        public static string ToXmlExt<T>(this T obj)
             where T : class
        {
            return obj == null ? null : ServiceStack.Text.XmlSerializer.SerializeToString(obj);
        }

        /// <summary>
        /// 转换成XML字符串,对象为空时返回null
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <param name="isRemoveDeclaration">是否去掉XML声明。</param>
        /// <returns></returns>
        public static string ToXmlExtV2<T>(this T obj, bool isRemoveDeclaration = true)
             where T : class
        {
            // 0.数据检查
            if (obj.IsNullOrEmpty()) return null;

            // 1.获取定制的xml序列化器
            XmlWriterSettings xmlSetting = new XmlWriterSettings
            {
                //忽略XML声明
                OmitXmlDeclaration = isRemoveDeclaration,
                Indent = true,
                Encoding = Encoding.UTF8,
            };
            IContentSerializer xmlSeria = new XmlContentSerializer(xmlSetting);

            // 2.序列化并返回
            return xmlSeria.SerializeToString(obj);
        }

        /// <summary>
        /// MKPL Cumstom extension metohed: Auto Convert object to Json
        /// </summary>
        /// <typeparam name="T">Object Type</typeparam>
        /// <param name="obj">the given original object</param>
        /// <param name="dateTimeFormat">
        /// 时间格式化字符串。(DateTime Format-String for Json Serializ)
        /// </param>
        /// <returns>Json format string</returns>
        public static string ToJsonExt<T>(this T obj, string dateTimeFormat = "MM\\/dd\\/yyyy HH:mm:ss")
            where T : class
        {
            if (obj == null) return null;

            var setting = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore
            };
            var timeConverter = new IsoDateTimeConverter { DateTimeFormat = dateTimeFormat };
            setting.Converters.Add(timeConverter);

            return JsonConvert.SerializeObject(obj, Newtonsoft.Json.Formatting.Indented, setting);
        }

        /// <summary>
        /// MKPL Cumstom extension metohed: Auto convert the Objcet to a int? type
        /// </summary>
        /// <param name="value">the given original object</param>
        /// <returns>the convert result</returns>
        public static int? ToIntegerExt<T>(this T value)
        {
            if (null == value) return null;
            if (DBNull.Value == (value as DBNull)) return null;

            if (int.TryParse(value.ToString(), out int integerValue))
            {
                return integerValue;
            }

            return null;
        }

        /// <summary>
        /// 判断是否为null，null或内容为空都返回true
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool IsNullOrEmpty<T>(this T value)
          where T : class
        {
            //引用为null
            bool isObjectNull = value == null;
            if (isObjectNull == true) return true;

            //内容为null
            IEnumerator tempEnumerator = (value as IEnumerable)?.GetEnumerator();
            if (tempEnumerator == null) return false;//这里出去代表是对象且引用不为null

            //到这里就代表是集合且引用不为空，判断有没有内容
            //MoveNext方法返回tue代表集合中至少有一个数据
            bool isLenth = tempEnumerator.MoveNext() == false;
            if (isLenth == true) return true; //这里出去代表数组长度为0

            return isLenth;
        }

        /// <summary>
        /// 判断是否为null，null或内容为空都返回false
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool IsNotNullOrEmpty<T>(this T value)
          where T : class
        {
            //IsNullOrEmpty取反
            return !value.IsNullOrEmpty();
        }

        /// <summary>
        /// ServiceStack中的ToCsv，这里只是包装下方便调用
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string ToCsvString<T>(this T str)
        {
            return str.ToCsv<T>();
        }

        /// <summary>
        /// 判断对象是否，是指定类型
        /// </summary>
        /// <typeparam name="T">要判断的源类型</typeparam>
        /// <param name="object1">源类型的对象，可以为null</param>
        /// <param name="targetType">指定类型</param>
        /// <returns>
        /// 如果相等，则为true，否则为false。<para></para>
        /// 如果是继承关系，为false。
        /// 如果obect为null，也不会影响判断
        /// </returns>
        public static bool EqualsType<T>(this T object1, Type targetType)
        {
            return (typeof(T)).Equals(targetType);
        }
    }
}