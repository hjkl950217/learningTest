﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DecimalExtension.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   DecimalExtension created at  3/15/2018 3:58:27 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using System;
using System.Globalization;
using System.Text;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// Decimal扩展类
    /// </summary>
    public static class DecimalExtend
    {
        /// <summary>
        /// 只保留整数部分后，再把值转换为指定精度，保留固定小数位.最少1位
        /// </summary>
        /// <param name="value">要处理的值</param>
        /// <param name="accuracyNum">小数点后的位数</param>
        /// <returns></returns>
        public static decimal FloorExt(this decimal value, int accuracyNum = 1)
        {
            if (accuracyNum <= 0)
                throw new ArgumentException(@"When attempting 'FloorExt', the accuracyNum parameter cannot be less than 0", nameof(accuracyNum));

            //处理格式化字符串
            StringBuilder startStr = new StringBuilder();
            startStr.Append("{0:0.");

            for (int i = 0 ; i < accuracyNum ; i++)//添加小数点后的位数
            {
                startStr.Append("0");
            }
            startStr.Append("}");

            //舍去多余部分
            value = Math.Floor(value);

            //固定精度
            string str = string.Format(CultureInfo.InvariantCulture, startStr.ToString(), value);

            return Convert.ToDecimal(str);
        }

        /// <summary>
        /// 把值转换为指定精度,4舍5入，保留固定小数位.最少1位
        /// </summary>
        /// <param name="value">要处理的值</param>
        /// <param name="accuracyNum">小数点后的位数</param>
        /// <returns></returns>
        public static decimal FixExt(this decimal value, int accuracyNum = 1)
        {
            if (accuracyNum <= 0) throw new ArgumentException(@"When attempting 'FixExt', the accuracyNum parameter cannot be less than 0", nameof(accuracyNum));

            //处理格式化字符串
            StringBuilder startStr = new StringBuilder();
            startStr.Append("{0:0.");

            for (int i = 0 ; i < accuracyNum ; i++)//添加小数点后的位数
            {
                startStr.Append("0");
            }
            startStr.Append("}");

            string str = string.Format(CultureInfo.InvariantCulture, startStr.ToString(), value);

            return Convert.ToDecimal(str);
        }
    }
}