﻿using Mkpl.Sdk.Core.Nair;
using System;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core
{
    public static class NairCacheExtension
    {
        public static T GetOrAdd<T>(
          this INairCache nairCache,
          string key,
          Func<T> getData)
          where T : class
        {
            T result = default;
            result = nairCache.TryGet<T>(key);

            if (result.IsNullOrEmpty())
            {
                result = getData?.Invoke();
                nairCache.Add(key, result);
            }

            return result;
        }

        public static async Task<TResult> GetOrAddAsync<TResult>(
         this INairCache nairCache,
         string key,
         Func<Task<TResult>> getData)
         where TResult : class
        {
            TResult result = default;
            result = nairCache.TryGet<TResult>(key);

            if (result.IsNullOrEmpty())
            {
                result = await getData?.Invoke();
                nairCache.Add(key, result);
            }

            return result;
        }
    }
}