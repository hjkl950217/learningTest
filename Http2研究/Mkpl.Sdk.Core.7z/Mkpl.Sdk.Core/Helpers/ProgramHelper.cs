﻿using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Mkpl.Sdk.Core.Exceptions;
using Newegg.MIS.Pikaq.Hydra.Config;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Mkpl.Sdk.Core.Helpers
{
    /// <summary>
    /// MPS组web应用启动帮助类
    /// </summary>
    /// <typeparam name="TStartup">项目中的Startup类</typeparam>
    public class ProgramHelper<TStartup>
        where TStartup : class
    {
        #region 各种环境变量

        /// <summary>
        /// 环境变量
        /// </summary>
        public string Env { get; protected set; }

        /// <summary>
        /// host地址
        /// </summary>
        /// <remarks>
        /// 程序的访问地址
        /// 通过DAE创建的项目会自动配置这个，其它方式需要指定
        /// Humpback默认会映射到8080，外部通过humpback映射的端口访问
        /// </remarks>
        public string ListenUrl { get; protected set; }

        /// <summary>
        /// Cluster 机器location, 只有集群模式才会有这个变量,humpback在集群模式时会自动配置。
        /// </summary>
        /// <remarks>
        /// 单机模式也可以自己配置。
        /// 固定值：gdev,gqc,wh7,e4,e11
        /// 产线配置:wh7,e4,e11
        /// </remarks>
        public string Location { get; protected set; }

        /// <summary>
        /// Eggkeeper取配置用的位置标识
        /// </summary>
        /// <remarks>
        /// 其它API模版中使用的是环境变量-EGGKEEPER_CLUSTER
        /// PRE PRD且非WH7时需要配置，而location是由Humpback配置的位置
        /// </remarks>
        public string EggkeeperCluster { get; protected set; }

        /// <summary>
        /// cluster container index 只有集群模式下才有这个变量，humpback在集群模式时会自动配置。
        /// </summary>
        public string Container_Index { get; protected set; }

        /// <summary>
        /// 单机模式下的SQL连接文件名
        /// </summary>
        /// <remarks>
        ///single(单机)模式下必须配置该参数.
        ///GDEV 和 GQC 可以不用配置该参数。
        /// </remarks>
        public string Sql_Database_file { get; protected set; }

        /// <summary>
        /// Hydra的Token
        /// </summary>
        public string HydraToken { get; protected set; }

        /// <summary>
        /// Hydra网关
        /// </summary>
        public string HydraGateway { get; protected set; }

        /// <summary>
        /// 是否启用Hydra
        /// </summary>
        public bool IsUseHydra { get; protected set; }

        #endregion 各种环境变量

        #region 属性

        /// <summary>
        /// 系统运行根目录
        /// </summary>
        public string CurrentDirectory { get; protected set; }

        /// <summary>
        /// sql 文件路径
        /// </summary>
        public string DbDirectory { get; protected set; }

        /// <summary>
        /// sql 文件列表
        /// </summary>
        /// <remarks>
        /// 在InitConfig方法中用IConfigurationBuilder的方法写入数据
        /// </remarks>
        public List<string> SqlConfigs { get; protected set; }

        /// <summary>
        /// 需要排除的SQL文件
        /// </summary>
        public List<string> SqlBlackConfigs { get; protected set; }

        /// <summary>
        /// 微服务名
        /// </summary>
        public string SeviceName { get; protected set; }

        /// <summary>
        /// 初始化时输入的自定义命令参数
        /// </summary>
        public string[] Args { get; protected set; }

        #endregion 属性

        /// <summary>
        /// <![CDATA[初始化一个Mkpl.Sdk.Core.Helpers.ProgramHelper<TStartup>实例]]>
        /// </summary>
        /// <param name="serviceName">微服务名，如Seller就传递Seller，推荐用公共库的常量</param>
        /// <param name="args">自定义参数</param>
        /// <remarks>
        /// Microsoft.AspNetCore.WebHost类的
        /// <para>public static IWebHostBuilder CreateDefaultBuilder(string[] args)的描述</para>
        /// </remarks>
        public ProgramHelper(string serviceName, string[] args)
        {
            //环境变量
            this.Env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")?.ToUpper();
            this.ListenUrl = Environment.GetEnvironmentVariable("ASPNETCORE_URLS");
            this.Location = Environment.GetEnvironmentVariable("HUMPBACK_CLUSTER_LOCATION")?.ToUpper();
            this.EggkeeperCluster = this.Env.EqualsLoose(ApplicationEnvConst.PRE) ? "WH7" : this.Location;
            this.Container_Index = Environment.GetEnvironmentVariable("HUMPBACK_CLUSTER_CONTAINER_INDEX");
            this.Sql_Database_file = Environment.GetEnvironmentVariable("SQL_DATABASE_FILE") ?? this.Env;
            if (EnvHelper.IsDev() == true) this.Sql_Database_file = ApplicationEnvConst.GDEV;

            //Hydra环境变量
            this.HydraToken = Environment.GetEnvironmentVariable("HYDRA_TOKEN");
            this.HydraGateway = Environment.GetEnvironmentVariable("HYDRA_GATEWAY");
            string useHydraStr = Environment.GetEnvironmentVariable("IS_USE_HYDRA");
            if (bool.TryParse(useHydraStr, out bool boolValue))
            {
                this.IsUseHydra = boolValue;
            }
            else
            {
                this.IsUseHydra = false;
            }

            //属性
            this.CurrentDirectory = Directory.GetCurrentDirectory();
            this.DbDirectory = Path.Combine(this.CurrentDirectory, "DBConfigs");
            this.SqlConfigs = new List<string>();
            this.SqlBlackConfigs = new List<string>();
            this.SeviceName = serviceName;
            this.Args = args;
        }

        #region 各种配置方法

        /// <summary>
        /// 初始化eggkeeper和SQL连接配置
        /// </summary>
        /// <param name="builder"></param>
        protected virtual void InitConfig(IConfigurationBuilder builder)
        {
            #region 初始化SQL语句文件数据

            //加载黑名单-先排除所有连接文件
            string connDire = Path.Combine(this.DbDirectory);
            var balckList = Directory.EnumerateFiles(
                connDire,
                "*.xml",
                SearchOption.AllDirectories)
                .Select(i => i.Replace(this.DbDirectory + Path.DirectorySeparatorChar, ""));
            this.SqlBlackConfigs.AddRange(balckList);

            //加载白名单-包括SQL文件和选定的连接文件
            string connFile = this.DynamicLoadSqlConnectionFile();
            this.SqlConfigs.Add(connFile);//把计算出的连接文件放入白名单

            var rerult = builder.SetBasePath(this.DbDirectory)
                .AddJsonFile("DbCommandFiles.json", optional: true, reloadOnChange: false)
                .Build();

            var sqls = rerult.Get<SqlCommandFiles>()
                   .SqlFiles
                   .Select(t => $"SQL{Path.DirectorySeparatorChar}{t}");
            this.SqlConfigs.AddRange(sqls);//添加SQL语句文件到白名单中
            Console.WriteLine($"sqlConfigs:{ this.SqlConfigs.ToJsonExt()}");

            #endregion 初始化SQL语句文件数据

            //添加ConfigService上的配置
            builder.AddEnvironmentVariables()
               .UseEggKeeper(this.Env, "NeweggTracingConfig", true, this.EggkeeperCluster)
               .UseEggKeeper(this.Env, "MKPL_Common", true, this.EggkeeperCluster)
               .UseEggKeeper(this.Env, $"MKPL_{this.SeviceName}", true, this.EggkeeperCluster);
        }

        /// <summary>
        /// 添加SQL语句文件
        /// </summary>
        /// <param name="services"></param>
        protected virtual void InitDB(IServiceCollection services)
        {
            //Hydra
            if (this.IsUseHydra==true)
            {
                var hydraTokenList = new List<ServerTokenConfig>()
                {
                    new ServerTokenConfig()
                    {
                        HydraService = this.HydraGateway,
                        Token = new List<string>() { this.HydraToken }
                    }
                };

                services.UseHydra(hydraTokenList);
            }

            //向皮卡丘添加配置文件
            services
                .UseMSSql()
                .UseDataAccessConfigFromDirectory(
                    this.DbDirectory,
                    this.SqlBlackConfigs.ToArray(),
                    this.SqlConfigs.ToArray());
        }

        /// <summary>
        /// 根据环境变量动态生成SQL连接文件名
        /// </summary>
        /// <returns></returns>
        protected virtual string DynamicLoadSqlConnectionFile()
        {
            //集群模式，编排 sql 配置文件
            string dbFileName = string.Empty;
            bool isCluster = this.Location.IsNullOrEmpty() == false
                && (this.Container_Index.IsNullOrEmpty() == false);

            bool notPre = this.Location.EqualsLoose(ApplicationEnvConst.GDEV)
                || this.Location.EqualsLoose(ApplicationEnvConst.GQC);
            if (isCluster == false)//单机模式
            {
                //Path.DirectorySeparatorChar是取当前系统中的文件分隔符
                //window下是\ \\这样的，linux就是/
                dbFileName = $"Database{Path.DirectorySeparatorChar}db.{this.Sql_Database_file}.xml";
            }
            else if (notPre == true)//集群模式   非PRE PRD模式
            {
                dbFileName = $"Database{Path.DirectorySeparatorChar}db.{this.Location}.xml";
            }
            else//集群模式  PRE PRD模式
            {
                //根据 location 和 index 的奇，偶数 编排sql config 文件
                dbFileName = $"Database{Path.DirectorySeparatorChar}db.{this.Location + (this.Container_Index.ToIntExt() % 2 == 0 ? "02" : "01")}.xml";
            }

            return dbFileName;
        }

        /// <summary>
        /// 检查环境变量
        /// </summary>
        protected virtual void CheckEnvironment()
        {
            //环境名
            if (string.IsNullOrWhiteSpace(this.Env))
            {
                throw new EnvironmentException("system environment variable [ASPNETCORE_ENVIRONMENT] is required");
            }

            //SQL环境变量
            //当程序运行环境为PRE或则PRD的时候，需要保证sql配置文件被正确加载。 
            if (string.Equals(this.Env, "PRE") || string.Equals(this.Env, "PRD"))
            {
                // 如果 location 和 container_Index 任意一个为空，则表示单机模式，而单机模式我们需要配置 SQL_DATABASE_FILE。这样才能读取到正确的sql配置。 
                if (string.IsNullOrEmpty(this.Location) || string.IsNullOrEmpty(this.Container_Index))
                {
                    //如果单机模式没有配置SQL_DATABASE_FILE 则给出错误提示。 
                    if (string.IsNullOrEmpty(Environment.GetEnvironmentVariable("SQL_DATABASE_FILE")))
                    {
                        throw new EnvironmentException("system environment variable [SQL_DATABASE_FILE] is required. the value can be set as: E1101 E1102 E401 E402.");
                    }
                }
            }
        }

        #endregion 各种配置方法

        #region 创建IWebHost

        /// <summary>
        /// 创建MPS组微服务对应的IWebHost
        /// </summary>
        /// <returns></returns>
        public IWebHostBuilder BuildWebHost()
        {
            this.CheckEnvironment();
            Console.WriteLine($"ContentRoot：{this.CurrentDirectory}");

            return WebHost.CreateDefaultBuilder(this.Args)
               .UseKestrel()//UseKestrel 创建 Web 服务器并且对代码进行托管
               .UseUrls(this.ListenUrl)
               .UseContentRoot(this.CurrentDirectory)
               .ConfigureAppConfiguration(config => this.InitConfig(config))
               .ConfigureServices(services => this.InitDB(services))
               .UseStartup<TStartup>();
        }

        #endregion 创建IWebHost
    }
}