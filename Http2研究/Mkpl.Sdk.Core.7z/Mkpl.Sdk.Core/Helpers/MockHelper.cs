﻿using Microsoft.Extensions.DependencyInjection;
using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Newegg.MIS.Pikaq.Abstraction;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// 获取单元测试中需要的对象，这些对象都是有复杂关系的
    /// </summary>
    public static class MockHelper
    {
        /// <summary>
        /// 标示是否创建过
        /// </summary>
        public static bool IsCreated { get; private set; } = false;

        /// <summary>
        /// 缓存的IDbManager
        /// </summary>
        private static IDbManager dbManager;

        /// <summary>
        /// 获取一个真实访问数据库的IDbManager
        /// </summary>
        /// <param name="directory">DB相关的文件夹</param>
        /// <param name="testEnv">数据库环境</param>
        /// <param name="sqlFile">sql语句集合文件</param>
        /// <returns></returns>
        /// <remarks>
        /// 建议单元测试项目中用一个静态字段，这样只会创建一次
        /// <para></para>
        /// 访问的SQL文件的文件夹：DBConfigs
        /// <para></para>
        /// 访问的连接文件：Database/db.GDEV.xml
        /// <para></para>
        /// 访问的SQL语句集合文件：DbCommandFiles.json
        /// <para></para>
        /// </remarks>
        public static IDbManager GetRealManager(
            string directory = "DBConfigs",
            string testEnv = ApplicationEnvConst.GDEV,
            string sqlFile = "DbCommandFiles.json")
        {
            if (MockHelper.IsCreated == true) return MockHelper.dbManager;

            string currentDirectory = Directory.GetCurrentDirectory();//程序运行环境
            string dBDirectory = Path.Combine(currentDirectory, directory);//SQL文件路径

            //加载黑名单-先排除所有连接文件
            List<string> blackList = new List<string>();
            string connDire = Path.Combine(dBDirectory, "Database");
            var balckList = Directory.EnumerateFiles(connDire, "*.xml", SearchOption.AllDirectories)
                        .Select(i => i.Replace(dBDirectory + Path.DirectorySeparatorChar, ""));
            blackList.AddRange(balckList);

            //加载白名单-包括SQL文件和选定的连接文件
            string connFile = $"Database{Path.DirectorySeparatorChar}db.{testEnv}.xml";//构建连接文件名
            string fileName = Path.Combine(currentDirectory, directory, sqlFile);
            string sqlContent = File.ReadAllText(fileName);

            var sqls = JsonConvert
                .DeserializeObject<SqlCommandFiles>(sqlContent)
                .SqlFiles
                .Select(t => $"SQL{Path.DirectorySeparatorChar}{t}");//构建SQL语句文件名

            //把读取的SQL文件名和连接文件合在一起
            List<string> whiteList = new List<string>(sqls)
            {
                connFile
            };

            //创建
            var provider = new ServiceCollection()
                .UseMSSql()
                .UseDataAccessConfigFromDirectory
                (
                    dBDirectory,
                    blackList.ToArray(),
                    whiteList.ToArray()
                )
                .BuildServiceProvider();

            //获取并返回
            MockHelper.dbManager = provider.GetService<IDbManager>();
            if (MockHelper.dbManager != null)
            {
                MockHelper.IsCreated = true;
                return dbManager;
            }
            else
            {
                throw new System.InvalidOperationException("Failed to create 'IDbManager', please check the required file");
            }
        }
    }
}