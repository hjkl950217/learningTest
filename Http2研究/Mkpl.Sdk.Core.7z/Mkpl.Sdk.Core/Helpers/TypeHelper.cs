﻿namespace Mkpl.Sdk.Core.Helpers
{
    public static class TypeHelper
    {
        /// <summary>
        /// 检查类型是否兼容
        /// </summary>
        /// <typeparam name="TSource">源类型，一般为接口</typeparam>
        /// <typeparam name="Traget">目标类型，要检查的类型</typeparam>
        /// <returns></returns>
        public static bool IsType<TSource, Traget>()
        {
            return typeof(TSource) == typeof(Traget);
        }
    }
}