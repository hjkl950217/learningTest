﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System;

namespace Mkpl.Sdk.Core.Helpers
{
    /// <summary>
    /// 环境帮助类
    /// </summary>
    public static class EnvHelper
    {
        /// <summary>
        /// 判断当前环境是否是PRE PRD
        /// </summary>
        /// <returns>为true时表示是PRE PRD环境</returns>
        /// <remarks>
        /// 取环境变量中的ASPNETCORE_ENVIRONMENT值
        /// <para>当取出的值等于GDEV GQC  Development时，返回的是false</para>
        /// <para>当取出的值是其它时，返回的是true</para>
        /// </remarks>
        public static bool IsPreOrPrd()
        {
            string envName = EnvHelper.GetEnv();

            //判断是否是PER以上的环境
            bool notPre = (envName.EqualsLoose(ApplicationEnvConst.Development) == true)
                || (envName.EqualsLoose(ApplicationEnvConst.GDEV) == true)
                || (envName.EqualsLoose(ApplicationEnvConst.GQC) == true);

            return notPre == false;
        }

        /// <summary>
        /// 判断当前环境是否是PRD
        /// </summary>
        /// <returns>为true时表示是PRD环境</returns>
        /// <remarks>
        /// 取环境变量中的ASPNETCORE_ENVIRONMENT值
        /// <para>当取出的值等于PRE、GQC、Development时，返回的是false</para>
        /// <para>当取出的值是其它时，返回的是true</para>
        /// </remarks>
        public static bool IsPrd()
        {
            string envName = EnvHelper.GetEnv();

            //判断是否是PRD
            bool noPrd = (envName.EqualsLoose(ApplicationEnvConst.Development) == true)
                || (envName.EqualsLoose(ApplicationEnvConst.GDEV) == true)
                || (envName.EqualsLoose(ApplicationEnvConst.GQC) == true)
                || (envName.EqualsLoose(ApplicationEnvConst.PRE) == true);

            return noPrd == false;
        }

        /// <summary>
        /// 是否是开发环境
        /// </summary>
        /// <returns>为true时表示是开发环境环境</returns>
        /// <remarks>
        /// 取环境变量中的ASPNETCORE_ENVIRONMENT值
        /// <para>当取出的值等于GDEV 或 Development时，返回的是true</para>
        /// </remarks>
        public static bool IsDev()
        {
            string envName = EnvHelper.GetEnv();

            //判断是否是开发环境
            bool isDev = (envName.EqualsLoose(ApplicationEnvConst.Development) == true)
                || (envName.EqualsLoose(ApplicationEnvConst.GDEV) == true);

            return isDev;
        }

        /// <summary>
        /// 是否是集成测试环境
        /// </summary>
        /// <returns>为true时表示是开发环境环境</returns>
        /// <remarks>
        /// 取环境变量中的ASPNETCORE_ENVIRONMENT值
        /// <para>当取出的值等于GDEV 或 Development时，返回的是true</para>
        /// </remarks>
        public static bool IsGqc()
        {
            string envName = EnvHelper.GetEnv();

            //判断是否集成测试环境
            bool isGqc = envName.EqualsLoose(ApplicationEnvConst.GQC) == true;

            return isGqc;
        }

        /// <summary>
        /// 获取当前的环境，如GDEV,GQC
        /// </summary>
        /// <remarks>当ASPNETCORE_ENVIRONMENT对应的值没有数据时，默认为GDEV</remarks>
        /// <returns>一个长度大于0的字符串，或“GDEV”</returns>
        public static string GetEnv()
        {
            string env = System.Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")
                ?.Trim()
                .ToUpper();

            return env.IsNullOrEmpty() == true ? ApplicationEnvConst.GDEV : env;
        }

        /// <summary>
        /// 获取创世纪中当前项目被分配的项目ID
        /// </summary>
        /// <returns>如果取到则返回有值的数据，没有取到返回""</returns>
        public static string GetGenesisProjectId()
        {
            string projectId = Environment.GetEnvironmentVariable("GENESIS_PROJECT_ID");

            if (projectId.IsNullOrEmpty() == true)
            {
                projectId = string.Empty;
            }

            return projectId;
        }
    }
}