﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ValidationHelper.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   ValidationHelper created at  2/23/2018 4:27:57 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mkpl.Sdk.Core.Helpers
{
    public static class ValidationHelper
    {
        public static bool IsDateTime(string value)
        {
            return DateTime.TryParse(value, out DateTime dateTime);
        }

        public const int MaximumIntValue = 99999999;
        public const decimal MaximumDecimalValue = 99999999.99M;
        public const decimal MinimumDecimalValue = -99999999.99M;
        public const double MaximumDoubleValue = 99999999.99D;

        public const int MaximumQtyValue = 99999999;
        public const decimal MaximumCurrencyValue = 99999999.99M;
        public const decimal MaximumCurrencyExchangeRateValue = 999999.999999M;
        public const decimal MaximumWeightValue = 99999999.99M;
        public const decimal MaximumSizeValue = 999999.99M;

        public static readonly DateTime MinimumSQLDate = new DateTime(1753, 1, 1, 0, 0, 0);
        public static readonly DateTime MaximumSQLDate = new DateTime(9999, 12, 31, 0, 0, 0);

        public static bool IsSQLDate(string value)
        {
            if (!IsDateTime(value))
            {
                return false;
            }

            if (!DateTime.TryParse(value, out DateTime theDate))
            {
                return false;
            }

            return IsSQLDate(theDate);
        }

        public static bool IsSQLDate(DateTime? value)
        {
            if (!value.HasValue)
            {
                return true;
            }

            var theDate = value.Value;

            return
                theDate.CompareTo(MinimumSQLDate) >= 0 &&
                theDate.CompareTo(MaximumSQLDate) <= 0;
        }

        /// <summary>
        ///  validate datetime format except null WhiteSpace
        /// </summary>
        /// <param name="value"></param>
        /// <returns>if datetime,null,WhiteSpace then true else false</returns>
        public static bool IsDateTimeExceptWhiteSpaceAndNull(string value)
        {
            if (String.IsNullOrWhiteSpace(value))
            {
                return true;
            }
            return IsDateTime(value);
        }

        /// <summary>
        /// Validate Legal Characters
        /// replace with reg
        /// </summary>
        /// <param name="strSource"></param>
        /// <returns></returns>
        public static bool IsLegalCharacters(string strSource)
        {
            if (!String.IsNullOrWhiteSpace(strSource) && (strSource.Contains("'")
                    || strSource.Contains("--")))
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Validate Legal Characters and MaxLength
        /// replace with reg
        /// </summary>
        /// <param name="strSource"></param>
        /// <param name="maxLength"></param>
        /// <returns></returns>
        public static bool IsLegalCharacters(string strSource, int maxLength)
        {
            if (!String.IsNullOrWhiteSpace(strSource))
            {
                if (strSource.Contains("'")
                    || strSource.Contains("--"))
                {
                    return false;
                }
                if (strSource.Length > maxLength)
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// validate list of string , not contain [Null,WhiteSpace string,repeat string,empty list]
        /// </summary>
        /// <param name="sourcelist"></param>
        /// <param name="maxLength"></param>
        /// <returns></returns>
        public static bool IsNormalListExceptEmptyAndNull(
            ICollection<string> sourcelist,
            int maxLength)
        {
            if (null == sourcelist || !sourcelist.Any())
            {
                return true;
            }
            var hashList = new HashSet<string>();
            foreach (var item in sourcelist)
            {
                if (String.IsNullOrWhiteSpace(item))
                {
                    return false;
                }
                if (!IsLegalCharacters(item, maxLength))
                {
                    return false;
                }
                if (hashList.Contains(item.Trim()))
                {
                    return false;
                }
                hashList.Add(item.Trim());
            }
            return true;
        }

        /// <summary>
        /// validate list of string , not contain [Null,WhiteSpace string,repeat string,empty list]
        /// </summary>
        /// <param name="sourcelist">source list </param>
        /// <returns></returns>
        public static bool IsNormalListExceptEmptyAndNull(ICollection<string> sourcelist)
        {
            if (null == sourcelist || !sourcelist.Any())
            {
                return true;
            }
            var hashList = new HashSet<string>();
            foreach (var item in sourcelist)
            {
                if (String.IsNullOrWhiteSpace(item))
                {
                    return false;
                }
                if (!IsLegalCharacters(item))
                {
                    return false;
                }
                if (hashList.Contains(item.Trim()))
                {
                    return false;
                }
                hashList.Add(item.Trim());
            }
            return true;
        }

        /// <summary>
        /// validate list of string , not contain [Null,repeat data,empty list]
        /// </summary>
        /// <param name="sourcelist">source list </param>
        /// <returns></returns>
        public static bool IsNormalListExceptEmptyAndNull(ICollection<int?> sourcelist)
        {
            if (sourcelist == null || !sourcelist.Any())
            {
                return true;
            }
            var hashList = new HashSet<int>();
            foreach (var item in sourcelist)
            {
                if (!item.HasValue)
                {
                    return false;
                }
                if (hashList.Contains(item.Value))
                {
                    return false;
                }
                hashList.Add(item.Value);
            }
            return true;
        }

        #region Numbers validations

        public static bool IsNonNegativeNumber(int? value)
        {
            return IsNonNegativeInteger(value);
        }

        public static bool IsNonNegativeNumber(decimal? value)
        {
            return IsNonNegativeDecimal(value);
        }

        public static bool IsNonNegativeNumber(double? value)
        {
            return IsNonNegativeDouble(value);
        }

        public static bool IsNonNegativeNumber(int value)
        {
            return IsNonNegativeInteger(value);
        }

        public static bool IsNonNegativeNumber(decimal value)
        {
            return IsNonNegativeDecimal(value);
        }

        public static bool IsNonNegativeNumber(double value)
        {
            return IsNonNegativeDouble(value);
        }

        public static bool IsPositiveNumber(int? value)
        {
            return IsPositiveInteger(value);
        }

        public static bool IsPositiveNumber(decimal? value)
        {
            return IsPositiveDecimal(value);
        }

        public static bool IsPositiveNumber(double? value)
        {
            return IsPositiveDouble(value);
        }

        public static bool IsPositiveNumber(int value)
        {
            return IsPositiveInteger(value);
        }

        public static bool IsPositiveNumber(decimal value)
        {
            return IsPositiveDecimal(value);
        }

        public static bool IsPositiveNumber(double value)
        {
            return IsPositiveDouble(value);
        }

        private static bool IsPositiveInteger(int? value)
        {
            if (!value.HasValue) return true;
            return value.Value > 0;
        }

        private static bool IsPositiveInteger(int value)
        {
            return value > 0;
        }

        private static bool IsNonNegativeInteger(int? value)
        {
            if (!value.HasValue) return true;
            return value.Value >= 0;
        }

        private static bool IsNonNegativeInteger(int value)
        {
            return value >= 0;
        }

        private static bool IsPositiveDecimal(decimal? value)
        {
            if (!value.HasValue) return true;
            return value.Value > 0m;
        }

        private static bool IsPositiveDecimal(decimal value)
        {
            return value > 0m;
        }

        private static bool IsNonNegativeDecimal(decimal? value)
        {
            if (!value.HasValue) return true;
            return value.Value >= 0m;
        }

        private static bool IsNonNegativeDecimal(decimal value)
        {
            return value >= 0m;
        }

        private static bool IsPositiveDouble(double? value)
        {
            if (!value.HasValue) return true;
            return value.Value > 0d;
        }

        private static bool IsPositiveDouble(double value)
        {
            return value > 0d;
        }

        private static bool IsNonNegativeDouble(double? value)
        {
            if (!value.HasValue) return true;
            return value.Value >= 0d;
        }

        private static bool IsNonNegativeDouble(double value)
        {
            return value >= 0d;
        }

        #endregion Numbers validations

        #region Decimal

        public static bool CheckDecimalDigits(decimal? value, int minDecimalLength)
        {
            if (!value.HasValue) return true;

            if (minDecimalLength <= 0) return true;

            var splitDecimal = value.ToString().Split(new[] { '.' });

            if (splitDecimal.Length != 2) return true;

            return splitDecimal[1].Length <= minDecimalLength;
        }

        public static bool ContainsOnlyTwoDecimalDigits(decimal? value)
        {
            if (!value.HasValue) return true;

            var splitDecimal = value.ToString().Split(new[] { '.' });

            if (splitDecimal.Length != 2) return true;

            return splitDecimal[1].Length <= 2;
        }

        #endregion Decimal

        private const int MaxAnsiCode = 255;

        public static bool ContainsUnicodeCharacter(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return false;

            return input.Any(c => c > MaxAnsiCode);
        }

        public static bool NotContainsUnicodeCharacter(string input)
        {
            return ContainsAnsiCharacterOnly(input);
        }

        public static bool ContainsAnsiCharacterOnly(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return true;

            return input.All(c => c <= MaxAnsiCode);
        }
    }
}