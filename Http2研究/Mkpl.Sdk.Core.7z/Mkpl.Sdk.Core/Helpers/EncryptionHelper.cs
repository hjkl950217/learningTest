﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EncryptionHelper.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   EncryptionHelper created at  2/10/2018 2:16:06 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
using NETCore.Encrypt;
using System;
using System.Security.Cryptography;
using System.Text;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// 加密解密帮助类
    /// </summary>
    public static class EncryptionHelper
    {
        #region 密钥与加密向量

        /// <summary>
        /// RSA  Public Key
        /// </summary>
        private const string RSAPublicKey = "{ 'Modulus':'roifTeDz23cV8pFZ2hhGghSdaUUImYJYjAHUmCJP11ZRumIhCgMbeXLWm9m6natAvTffdevX40BO3+Uns3wP3PmSu24UFrIVoKH7A/XVjvuPInxQSL4zie2uhJahpooyMUcm/5SFmXkHve8NXsZtHbgAGKGkS2ksVnkDoQgMHYc=', 'Exponent':'AQAB' }";

        /// <summary>
        /// RSA Private Key
        /// </summary>
        private const string RSAPrivateKey = "{'Modulus':'roifTeDz23cV8pFZ2hhGghSdaUUImYJYjAHUmCJP11ZRumIhCgMbeXLWm9m6natAvTffdevX40BO3+Uns3wP3PmSu24UFrIVoKH7A/XVjvuPInxQSL4zie2uhJahpooyMUcm/5SFmXkHve8NXsZtHbgAGKGkS2ksVnkDoQgMHYc=','Exponent':'AQAB','P':'8hTjEy8SA2JF+gonFgbsbFNcNZKQN/wwz3uAVqYEXroxMpYf3zIIrvyXn8jmOsEgoVJTqIv3IrrVf2UGtqcV+Q==','Q':'uJGFheb9USrKWcZ9Q/zGgkTFfwSWgsFxtd5uR0J1jPLDYULQdl4iEsgctBa+oCbN2UYlJcCGabf1JQ9U6Puvfw==','DP':'yHtZzzJlRZ4me7vawNg9Bj1HGSrm+yaFOd962sekyNqEEfPYM1zZainQXEjhunjk0BVBKU24/u8iDt4Y4D2h6Q==','DQ':'dK7LExQtIZtDwe3SU6ECfmir0tk7rf5NvQSaA0LoverbyilLUQnB0M3iF5gpe2YMzUejRHKqhztdJ8jBjWlQUQ==','InverseQ':'pl4R0uXF9kmk8XnV/erQIxV8yA/f3qahzf7bQlKsUThtEV2B5ERVhzniQhFP+3fIr0G2LOLF9d2Ws+3UdWnnBg==','D':'gz3nFMfgd5pv3YxhFXgFpRFdYOhxVAXJEdbah1/dy95z7ISXtZCqm0O4j09FXgSF1QNrvJ+RIqib5w7JMNVMkywg1xSkxOMXqvOsN2LThvYU0vhchXA2u8EfQfrbO+sj44YtX5eHNS8HcPTIiLLK3r/86RkiQIIG4FgBOD8QYBE='}";

        /// <summary>
        /// AES Secret Key
        /// </summary>
        private const string AESSecretKey = "Guz(%&hj7x89H$yuBI0456FtmaT5&fvHUFCy76*h%(HilJ$lhj!y6&(*jkP87jH7";

        /// <summary>
        /// AES Encryption Vector
        /// </summary>
        private const string AESEncryptionVector = "E4ghj*Ghg7!rNIfb&95GUY86GfghUb#er57HBh(u%g6HJ($jhWk7&!hg4ui%$hjk";

        #endregion 密钥与加密向量

        #region 密钥计算方法

        /// <summary>
        /// 获得可用的AES密钥
        /// </summary>
        /// <returns>密钥</returns>
        private static string GetAESLegalKey()
        {
            var sTemp = AESSecretKey;

            var ase = EncryptProvider.CreateAesKey();
            var keyLength = ase.Key.Length;
            if (sTemp.Length > keyLength)
            {
                sTemp = sTemp.Substring(0, keyLength);
            }
            else if (sTemp.Length < keyLength)
            {
                sTemp = sTemp.PadRight(keyLength, ' ');//在右侧填充空字符
            }

            return sTemp;
        }

        /// <summary>
        /// 获得可用的AES初始向量
        /// </summary>
        /// <returns>初试向量IV</returns>
        private static string GetAESLegalVector()
        {
            var sTemp = AESEncryptionVector;

            var ase = EncryptProvider.CreateAesKey();
            var bytTemp = ase.IV;
            var ivLength = bytTemp.Length;

            if (sTemp.Length > ivLength)
            {
                sTemp = sTemp.Substring(0, ivLength);
            }
            else if (sTemp.Length < ivLength)
            {
                sTemp = sTemp.PadRight(ivLength, ' ');//在右侧填充空字符
            }

            return sTemp;
        }

        #endregion 密钥计算方法

        #region 公开加密与解密方法

        /// <summary>
        /// Encryp Passworld for login used
        /// </summary>
        /// <param name="content"> wait for Encryp string</param>
        /// <returns> Encryp string </returns>
        public static string RSAEncrypt(string content)
        {
            var rsa = EncryptProvider.RSAFromString(RSAPublicKey);
            var bytes = Encoding.Unicode.GetBytes(content);
            var encryptedBytes = rsa.Encrypt(bytes, RSAEncryptionPadding.Pkcs1);
            return Convert.ToBase64String(encryptedBytes, 0, encryptedBytes.Length);
        }

        /// <summary>
        /// Decryp Passworld for login used
        /// </summary>
        /// <param name="content">wait for Encryp Decryp</param>
        /// <returns>Decryp string</returns>
        public static string RSADecrypt(string content)
        {
            var rsa = EncryptProvider.RSAFromString(RSAPrivateKey);
            var bytes = Convert.FromBase64String(content);
            var decryptedBytes = rsa.Decrypt(bytes, RSAEncryptionPadding.Pkcs1);
            return Encoding.Unicode.GetString(decryptedBytes);
        }

        /// <summary>
        /// MKPL custom Method : AES Encrypt
        /// </summary>
        /// <param name="source">wait Encrypt string</param>
        /// <returns>Encrypt string</returns>
        public static string AESEncrypt(string source)
        {
            var key = GetAESLegalKey();
            var iv = GetAESLegalVector();
            var encryptedBytes = EncryptProvider.AESEncrypt(source, key, iv);
            return encryptedBytes;
        }

        /// <summary>
        /// MKPL custom Method : AES Decrypt
        /// </summary>
        /// <param name="source">wait Decrypt String</param>
        /// <returns>Decrypt String</returns>
        public static string AESDecrypt(string source)
        {
            var key = GetAESLegalKey();
            var iv = GetAESLegalVector();
            var encryptedBytes = EncryptProvider.AESDecrypt(source, key, iv);
            return encryptedBytes;
        }

        /// <summary>
        /// 对输入值做MD5计算，返回32位字符串
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static string MD5Encrypt32(string source)
        {
            if (source.IsNullOrEmpty() == true) return string.Empty;
            return EncryptProvider.Md5(source);
        }

        /// <summary>
        /// 对输入值做MD5计算，返回16位字符串
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static string MD5Encrypt16(string source)
        {
            if (source.IsNullOrEmpty() == true) return string.Empty;
            return EncryptProvider.Md5(source, MD5Length.L16);
        }

        #endregion 公开加密与解密方法
    }
}