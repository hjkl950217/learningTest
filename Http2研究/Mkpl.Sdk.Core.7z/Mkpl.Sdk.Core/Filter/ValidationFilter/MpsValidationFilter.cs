﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Mkpl.Sdk.Core.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// MPS组-模型验证拦截器
    /// </summary>
    /// <remarks>
    /// 由其他框架执行模型验证并把结果添加ModelState中，然后这里执行逻辑。
    /// <para>当模型无效时，会直接返回给前端，不会再执行后面的方法</para>
    /// </remarks>
    public class MpsValidationFilter : IAsyncActionFilter
    {
        /// <summary>
        /// 异步过滤器
        /// </summary>
        /// <param name="context"></param>
        /// <param name="next"></param>
        /// <returns></returns>
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            //执行next这个委托之前，都代表是动作方法执行之前

            bool isValid = context.ModelState.IsValid;

            if (isValid == false)//验证不过直接返回
            {
                context.Result = this.GetErrorObject(context);
                await Task.CompletedTask;//表示任务完成 直接返回
            }
            else
            {
                //执行下一个操作
                await next();
            }
        }

        /// <summary>
        /// 从ActionExecutingContext上下文中获取错误信息并处理成MPS的错误格式
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        protected virtual IActionResult GetErrorObject(ActionExecutingContext context)
        {
            //定义取错误消息内部方法
            string GetError(ModelError model)
            {
                return model.ErrorMessage.IsNullOrEmpty()
                    ? model.Exception.Message
                    : model.ErrorMessage;
            };

            //转换格式
            MpsValidationErrorOut errorOut = new MpsValidationErrorOut();
            foreach (var item in context.ModelState)
            {
                List<string> tempErrorList = item.Value.Errors?
                    .Select(t => GetError(t))
                    .ToList();

                errorOut.Errors.Add(item.Key, tempErrorList);
            }

            //处理返回数据
            ObjectResult result = new ObjectResult(errorOut)
            {
                StatusCode = (int)HttpStatusCode.BadRequest
            };

            return result;
        }
    }
}