# generate doc

```
cd Api.Template.WebAPI

dotnet aries doc -c apidocconfig.json

dotnet ariessub upload -c apidocconfig.json

```
# run Code coverage report
in the project roolt open windows CMD tool 
```
codeCoverage.sh
```
or
```
codeCoverage.sh [threshold]
```

in Git base command tool
```
$ ./codeCoverage.sh
```
or
```
$ ./codeCoverage.sh [threshold]
```
