﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ServerStatusDataService.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   ServerStatusDataService created at  2/24/2018 2:07:23 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------

using Mkpl.Item.DataAccess;

namespace Mkpl.Item.Repository
{
    /// <summary>
    /// 服务器状态DB层服务实现
    /// </summary>
    public class ServerStatusDAL : IServerStatusDAL
    {
        /// <summary>
        /// 数据访问接口实例
        /// </summary>
        private readonly IServerStatusDao ServerStatusDao;

        public ServerStatusDAL(IServerStatusDao serverStatusDao)
        {
            this.ServerStatusDao = serverStatusDao;
        }

        public bool IsDatabaseMaintenance()
        {
            return this.ServerStatusDao.IsDatabaseMaintenance();
        }
    }
}