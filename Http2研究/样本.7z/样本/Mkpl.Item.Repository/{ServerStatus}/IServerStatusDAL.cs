﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IServerStatusDataService.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   IServerStatusDataService created at  2/24/2018 2:04:28 PM
// </summary>
//<Discription>
//
//</Discription>
// --------------------------------------------------------------------------------------------------------------------

namespace Mkpl.Item.Repository
{
    /// <summary>
    /// 服务器状态仓储层接口
    /// </summary>
    public interface IServerStatusDAL
    {
        /// <summary>
        /// 检查DB 是否处于维护状态。false 表示正常运行，true表示处于维护状态。
        /// </summary>
        /// <returns></returns>
        bool IsDatabaseMaintenance();
    }
}