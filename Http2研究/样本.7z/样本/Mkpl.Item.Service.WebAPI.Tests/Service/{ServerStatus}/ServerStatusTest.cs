﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ServerStatusTest.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   ServerStatusServiceTest created at  2/28/2018 5:53:00 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
using Mkpl.Item.DataAccess;
using NSubstitute;
using System;
using System.IO;
using Xunit;

namespace Mkpl.Item.Service.WebAPI.Tests.Service
{
    // [Category( "ServerStatus" )]
    [Trait("Category" , "ServerStatus")]
    public class ServerStatusTest
    {
        [Theory(DisplayName = "Faq_ServerStatusService_IsServerActive")]
        [InlineData("DataBase is being maintained", true)]
        [InlineData("<!--Newegg-->" , false)]
        public void TC_ServerStatusService_IsServerActive(string expected , bool actual)
        {
            //拿到模拟接口实例
            var serverStatusDataService = Substitute.For<IServerStatusDao>();

            //注册模拟方法
            serverStatusDataService.IsDatabaseMaintenance().Returns(actual);

            var serverStatusService = new ServerStatusService(serverStatusDataService);

            var result = serverStatusService.IsServerActive();

            Assert.Contains(expected , result);
        }

        [Theory(DisplayName = "Faq_ServerStatusService_FAQ_Exist")]
        [InlineData("faq.htm" , true)]
        [InlineData("faq1.htm" , false)]
        public void TC_ServerStatusService_FAQ_Exist(string expected , bool actual)
        {
            var faqPath = Path.Combine($"{Directory.GetCurrentDirectory()}/wwwroot/{expected}");

            Assert.True(File.Exists(faqPath) == actual , "faq.htm Not Found");
        }

        [Theory(DisplayName = "Faq_ServerStatusService_Has_Exception")]
        [InlineData("Exception Test" , "Exception Test")]
        public void TC_ServerStatusService_Has_Exception(string expected , string actual)
        {
            var serverStatusDataService = Substitute.For<IServerStatusDao>();

            var serverStatusService = new ServerStatusService(serverStatusDataService);
            serverStatusDataService
                .When(x => x.IsDatabaseMaintenance())
                .Do(x => throw new Exception(actual));

            Exception exce = new Exception();
            string result = "";
            try
            {
                result = serverStatusService.IsServerActive();
            }
            catch( Exception ex )
            {
                exce = ex;
            }

            Assert.Contains(expected , result);
            Assert.Contains("Exception of type 'System.Exception' was thrown." , exce.Message);
        }

        [Theory(DisplayName = "Faq_ServerStatusService_Has_InnerException")]
        [InlineData("Inner Exception" , "Inner Exception Test")]
        public void TC_ServerStatusService_Has_InnerException(string expected , string actual)
        {
            //准备模拟数据与模拟接口
            var serverStatusDataService = Substitute.For<IServerStatusDao>();
            var serverStatusService = new ServerStatusService(serverStatusDataService);
            serverStatusDataService
                .When(x => x.IsDatabaseMaintenance())
                .Do(x => throw new Exception("Exception Test" , new Exception(actual)));

            Exception exce = new Exception();
            string result = "";

            //执行
            try
            {
                result = serverStatusService.IsServerActive();
            }
            catch( Exception ex )
            {
                exce = ex;
            }

            Assert.Contains(expected , result);
            Assert.Contains("Exception of type 'System.Exception' was thrown." , exce.Message);
        }
    }
}