﻿using System;
using Xunit;

namespace Mkpl.Item.Service.WebAPI.Tests
{
    [Trait("Category", "MainTest")]
    public class MainTest
    {
        [Fact]
        public void MainRunTest()
        {
            Environment.SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT" , "GDEV");
            Program.Main(new string[1] { "UT=true" });
        }
    }
}