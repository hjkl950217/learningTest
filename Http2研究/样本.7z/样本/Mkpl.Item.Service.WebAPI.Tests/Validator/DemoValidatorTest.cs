﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DemoValidatorTest.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   DemoValidatorTest created at  5/2/2018 3:49:26 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！


using System;
using Xunit;

namespace Mkpl.Item.Service.WebAPI.Tests.Validator
{
    /// <summary>
    /// 演示模型验证
    /// </summary>
    public class DemoValidatorTest
    {
        // todo:新建项目注意-Validator的单元测试

        /*
         * 如果你需要对Validator做单元测试，可以参考下面的示例代码编写
         */


        //[Theory]
        //[InlineData(null)]
        //[InlineData("")]
        //[InlineData(" ")]
        //[InlineData("0123456789|0123456789|0123456789|0123456789|0123456789|0123456789")]
        //public void ItemNumber_Invalid(string itemNumber)
        //{

        //创建具体的验证类
        //    var validator = new OrderDetailValidator();

        //调用ShouldHaveValidationErrorFor方法对模型上一个属性做验证
        //一个测试方法只针对一个属性
        //    validator.ShouldHaveValidationErrorFor(m => m.ItemNumber, itemNumber);
        //}

    }
}
