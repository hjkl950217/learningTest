﻿using AutoMapper;

using Mkpl.Item.Facade;
using System;
using System.Collections.Generic;
using Xunit;
using Xunit.Abstractions;

namespace Mkpl.Item.Service.WebAPI.Tests.Facade
{
    /// <summary>
    ///
    /// </summary>
    /// <remarks>
    /// 专门测试映射规则
    /// </remarks>
    [Trait("Category" , "AutoMapper")]
    public class MapperTest
    {
        private readonly IMapper Mapper;

        private readonly ITestOutputHelper OutputHelper;

        public MapperTest(ITestOutputHelper testOutputHelper)
        {
            this.OutputHelper = testOutputHelper;

            var config = new AutoMapper.MapperConfiguration(cfg =>
           {
               //配置替换字符，一定要在创建map之前
               //cfg.ReplaceMemberName( "Ä" , "A" );//把源类型属性名中的Ä替换成A

               //添加配置类，以后要添加也在这里添加
               cfg.AddProfile(new AutoMapProFile());

               // 映射具有public或internal的get的属性
               cfg.ShouldMapProperty = p =>
                  p.GetMethod != null
                  && ( p.GetMethod.IsPublic || p.GetMethod.IsAssembly );
           });
            config.AssertConfigurationIsValid();//启动自动验证映射规则是否正确
            this.Mapper = config.CreateMapper();
        }

        /// <summary>
        /// 基础验证
        /// </summary>
        /// <typeparam name="TSource">源类型</typeparam>
        /// <typeparam name="TDestination">需要被转换的目标类型</typeparam>
        /// <param name="source">需要被转换的源数据</param>
        /// <param name="destination">需要被转换的目的数据，用来测试不会new的转换</param>
        /// <remarks>
        /// 1.验证需要new的情况
        /// 2.验证不需要new的情况
        ///
        /// 只检查是否转换成功，具体值判断需要自己写
        /// 返回null代表失败
        /// </remarks>
        /// <returns>
        /// 返回null代表转换失败
        /// </returns>
        private TDestination BaseMapCheck<TSource, TDestination>(TSource source , TDestination destination)
            where TSource : class
            where TDestination : class, new()
        {
            var result = this.Mapper.Map<TDestination>(source);//新对象需要new
            this.Mapper.Map(source , destination);//新对象不需要new

            return result;
        }

 
    }
}