﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace Mkpl.Item.Service.WebAPI.Tests.Entity.Common
{

    [Trait("Category", "ConfigService")]
    public class Test_SellerDataTest
    {
        //todo:新建项目注意-实体的单元测试

        /*
         * 如果使用了充血模型，再在这里写上对应的单元测试
         */

    }
}
