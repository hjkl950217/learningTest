﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ServerStatusDataServiceTests.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   ServerStatusDataServiceTests created at  2/28/2018 5:06:08 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------

using Mkpl.Item.DataAccess;
using Newegg.MIS.Pikaq.Abstraction;
using NSubstitute;
using System;
using Xunit;

namespace Mkpl.Item.Service.WebAPI.Tests
{
    [Trait("Category" , "ServerStatus")]
    public sealed class ServerStatusDaoTests
    {
        private readonly IDbManager mock_IDbManager = Substitute.For<IDbManager>();

        [Fact]
        public void ServerStatusDao_IsDatabaseMaintenance_ThrowException()
        {
            mock_IDbManager
                .When(x => x.GetCommand("IsDatabaseMaintenance"))
                .Do(x => throw new Exception("DB Exception"));

            var serverStatusDA = new ServerStatusDao(this.mock_IDbManager);

            var result = serverStatusDA.IsDatabaseMaintenance();

            Assert.True(result);
        }

        [Fact]
        public void ServerStatusData_True()
        {
            var statusDataService = Substitute.For<IServerStatusDao>();
            statusDataService.IsDatabaseMaintenance().Returns(true);
            var result = statusDataService.IsDatabaseMaintenance();
            Assert.True(result);
        }

        [Fact]
        public void ServerStatusData_false()
        {
            var statusDataService = Substitute.For<IServerStatusDao>();
            statusDataService.IsDatabaseMaintenance().Returns(false);
            var result = statusDataService.IsDatabaseMaintenance();
            Assert.False(result);
        }
    }
}