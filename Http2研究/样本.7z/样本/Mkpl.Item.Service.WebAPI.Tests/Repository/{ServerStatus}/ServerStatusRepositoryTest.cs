﻿using Mkpl.Item.DataAccess;
using Mkpl.Item.Repository;
using NSubstitute;
using Xunit;

namespace Mkpl.Item.Service.WebAPI.Tests.Repository
{
    public class ServerStatusRepositoryTest
    {
        private static class MockHelp
        {
            public static IServerStatusDao GetMockServerStatusDao()
            {
                return Substitute.For<IServerStatusDao>();
            }
        }

        [Trait("Category", "ServerStatus")]
        public class TC_GetAllCountry
        {
            //todo:新建项目注意-业务代码的单元测试
            /*
             *
             * 接口和数据模拟：使用上面 private static class MockHelp 的方式
             * 理由是这样同一套业务中可以共用一个模拟数据，有修改的再在单元测试中修改即可。
             * 而且这种方式，每次获取的是新数据，不会与其它单元测试冲突（同一个引用有可能冲突）
             * 而且，如果有复杂的依赖关系，只需要写一套代码就行了。
             *
             * 如果复杂依赖中有多个接口需要模拟返回值，可使用  (A a,B b) GetMockXX()这种方式，
             * 再在单元测试中写模拟的返回值即可。
             * 
             * 
             * 单元测试方法：命名为TC_方法名_其它_其它...
             * 
             * 类：类上面要加[Trait("Category", "ServerStatus")]这种标签
             *
             */

            public void TC_IsDatabaseMaintenance_True()
            {
                var mockDao = MockHelp.GetMockServerStatusDao();
                mockDao.IsDatabaseMaintenance()
                    .Returns(true);

                //执行
                var result = new ServerStatusDAL(mockDao)
                    .IsDatabaseMaintenance();

                //验证
                Assert.True(result);
            }
        }
    }
}