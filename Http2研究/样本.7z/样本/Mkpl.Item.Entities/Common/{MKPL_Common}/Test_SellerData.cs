﻿using Newegg.MIS.EggKeeper.Sdk.Default;

namespace Mkpl.Item.Entities.Common
{
    /// <summary>
    /// 自动化测试使用的数据
    /// </summary>
    /// <remarks>
    /// 位于ConfigServie的MKPL_Common/Test_SellerData下
    /// </remarks>
    [JsonEgg(ConfigName = "Test_SellerData")]
    public class Test_SellerData
    {
        //todo:新建项目注意-ConfigSrevice上的配置实体
        /*
         * 配置类的文件结构如本文件
         * Entities
         *      Common
         *             {MKPL_Common}
         *
         *
         * 表示Test_SellerData这个类的配置对应MKPL_Common下面的Test_SellerData节点
         *
         * 同时类上建议
         * 然后到Web层的ConfigExtension.cs文件中添加本类，这样在IOC中就可以获取了
         *
         *
         * 建议1：在类上打JsonEgg标签，显式声明关系，而且类名和ConfigService上的名字不一定一样
         * 建议2：在类的备注中，写明在ConfigService的位置
         * 建议3：配置类的属性都写上注释和备注，以免接手任务的同事不知道这个属性是干嘛
         */

        /// <summary>
        /// 基础描述1
        /// </summary>
        public string BaseDesription1 { get; set; }
    }
}