﻿using Mkpl.Sdk.Core;
using Newegg.MIS.Pikaq.Abstraction;
using Xunit;

namespace Mkpl.Item.RealDBTests
{
    public class TestDaoDebuger
    {
        [Fact]
        public void Test_Demo()
        {
            //todo:新建项目注意-真实DB单元测试

            /*
             * 有些业务场景里需要对SQL语句脚本和数据库中的数据会一些保证
             * 但业务逻辑的单元测试中应该包含真实DB访问，所以独立了一块专门用来测试
             * 
             * 使用如下方式获取DB管理器即可，其它的照旧。
             * 
             * 不推荐这种测试方式哦
             * 
             */

            IDbManager dbManager = MockHelper.GetRealManager();
        }
    }
}