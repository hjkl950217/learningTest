if [ ! -z $1 ]; then
  if [ $1 -lt 0 ] || [ $1 -gt 100 ]; then
    echo "Threshold should be between 0 and 100"
    threshold=80
  fi
  threshold=$1
else
  threshold=80
fi

echo "Current threshold is ：" $threshold

rm -rf coverage-html/
rm coverage.json
rm coverage-hits.txt

dotnet restore
dotnet build

cd Mkpl.Item.Service.WebAPI.Tests
dotnet restore

# Instrument assemblies inside 'test' folder to detect hits for source files inside 'src' folder
dotnet minicover instrument --workdir ../ --assemblies Mkpl.Item.Service.WebAPI.Tests/**/bin/**/*.dll --exclude-sources [Mkpl.Item.Resource,Mkpl.Item.Service.WebAPI.Tests,Mkpl.Item.RealDBTests]

# Reset hits count in case minicover was run for this project
dotnet minicover reset

cd ..

for project in Mkpl.Item.Service.WebAPI.Tests/*.csproj; do dotnet test --no-build $project; done

cd Mkpl.Item.Service.WebAPI.Tests

# Uninstrument assemblies, it's important if you're going to publish or deploy build outputs
dotnet minicover uninstrument --workdir ../

# Create HTML reports inside folder coverage-html
# This command returns failure if the coverage is lower than the threshold
dotnet minicover htmlreport --workdir ../ --threshold $threshold

# Print console report
# This command returns failure if the coverage is lower than the threshold
dotnet minicover report --workdir ../ --threshold $threshold

# Create NCover report
#dotnet minicover xmlreport --workdir ../ --threshold $threshold

start ../coverage-html/index.html
cd ..