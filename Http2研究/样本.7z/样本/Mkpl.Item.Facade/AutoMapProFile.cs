﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CountryProFile.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   CountryProFile created at  2018-03-02 16:21:06
// </summary>
//<Description>
//
//</Description>
// ---------------------------------------------------------------------------------------------------------------
using AutoMapper;

using Mkpl.Sdk.Core;
using System.Collections.Generic;

namespace Mkpl.Item.Facade
{
    /// <summary>
    /// 对象映射配置
    /// </summary>
    /// <remarks>
    /// 配置完记得在Web层中添加这个配置类
    /// </remarks>
    public class AutoMapProFile : Profile
    {
        public AutoMapProFile()
        : this(typeof(AutoMapProFile).Name)
        {
        }

        protected AutoMapProFile(string profileName)
        : base(profileName)
        {
            //映射规则调用


        }


    }
}