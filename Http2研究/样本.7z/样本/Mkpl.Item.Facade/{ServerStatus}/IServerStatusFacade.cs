﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CountryService.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   CountryService created at  2018-03-02 15:42:37
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------

namespace Mkpl.Item.Facade
{
    /// <summary>
    /// 服务器状态检查接口
    /// </summary>
    public interface IServerStatusFacade
    {
        /// <summary>
        /// 检查服务器是否可以访问。
        /// <para>1，检查服务是否存在FAQ.htm 文件，如果此文件不存在，则表示服务下线直接返回<!--##--> <br/> The server is Off line <br/>字符串。</para>
        /// <para>2，如果存在FAQ.htm 文件，则check 该服务器访问的DB是否处于维护状态。如果是维护状态则返回 <!--##--> <br/>Current DataBase is being maintained <br/>字符串。</para>
        /// <para>3，如果报异常，则返回异常信息字符串。</para>
        /// <para>4，若果服务一切正常则返回<!--Newegg-->字符串。</para>
        /// </summary>
        /// <returns></returns>
        string IsServerActive();
    }
}