﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Item.Facade
{
    /// <summary>
    /// 示例-In对象
    /// </summary>
   public class Demo_In
    {
        //todo:新建项目注意-Http请求中用到的对象
        /*
         * Http请求中会涉及到针对调用者，做的一些处理。所以一直以来都有DTO这个东西。
         * 在老项目中叫XXXRequest  XXXResponse对象
         * 
         * 
         * 在新版本中  叫In  Out  如本类的命名
         */

    }
}
