﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CountryService.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   CountryService created at  2018-03-02 15:42:37
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------

using Mkpl.Item.Service;

namespace Mkpl.Item.Facade
{
    /// <summary>
    /// 服务器状态检查接口实现
    /// </summary>
    public class ServerStatusFacade : IServerStatusFacade
    {
        /// <summary>
        /// 服务器状态
        /// </summary>
        private readonly IServerStatusService ServerStatusService;

        public ServerStatusFacade(IServerStatusService serverStatusService)
        {
            this.ServerStatusService = serverStatusService;
        }

        /// <summary>
        /// 检查服务器是否可以访问。
        /// 1，检查服务是否存在FAQ.htm 文件，如果此文件不存在，则表示服务下线直接返回<!--##--> <br/> The server is Off line <br/>字符串。
        /// 2，如果存在FAQ.htm 文件，则check 该服务器访问的DB是否处于维护状态。如果是维护状态则返回 <!--##--> <br/>Current DataBase is being maintained <br/>字符串。
        /// 3，如果报异常，则返回异常信息字符串。
        /// 4，若果服务一切正常则返回<!--Newegg-->字符串。
        /// </summary>
        /// <returns></returns>
        public string IsServerActive()
        {
            //todo:新建项目注意-Facade层职责
            /*
             * Facade层是为业务实体和DTO转换使用的。
             * 
             * 在这一层的方法中只有3个事：
             * 
             * 1.In对象-->业务实体
             * 2.调用业务层方法
             * 3.业务层方法的返回值-->Out对象
             * 
             * 尽量把变化的部分压缩到业务层去。
             * 如果转换规则有点复杂，有2个办法：
             * 
             * 1.说明你的设计有问题，需要拆分对象（多半是业务实体耦合度太高，比如50个属性的实体类）
             * 
             * 2.写一个专门的转换方法，在Facade层调用。代码也在Facade层
             * 
             */

            return this.ServerStatusService.IsServerActive();
        }
    }
}