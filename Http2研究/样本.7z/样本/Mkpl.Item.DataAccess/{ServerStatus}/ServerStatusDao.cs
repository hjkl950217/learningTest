﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ServerStatusDataService.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   ServerStatusDataService created at  2/24/2018 2:07:23 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------

using Newegg.MIS.Pikaq.Abstraction;

namespace Mkpl.Item.DataAccess
{
    /// <summary>
    /// 服务器状态DB层服务实现
    /// </summary>
    public class ServerStatusDao : IServerStatusDao
    {
        /// <summary>
        /// 数据访问接口实例
        /// </summary>
        private readonly IDbManager DbManager;

        public ServerStatusDao(IDbManager dbManager)
        {
            this.DbManager = dbManager;
        }

        public bool IsDatabaseMaintenance()
        {
            var isDatabaseMaintenance = 0;
            try
            {
                var command = this.DbManager.GetCommand("IsDatabaseMaintenance");

                isDatabaseMaintenance = command.ExecuteScalar<int>();
            }
            catch
            {
                isDatabaseMaintenance = 1;
            }

            return isDatabaseMaintenance == 1;
        }
    }
}