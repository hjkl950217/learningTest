﻿using Microsoft.Extensions.DependencyInjection;
using Mkpl.Item.Facade;

namespace Mkpl.Item.Service.WebAPI
{
    public static class RegisterMapConfig
    {
        /// <summary>
        /// 向IOC中注册接口与实例的关系
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddMapConfig(this IServiceCollection services)
        {
            //todo:新建项目注意-AutoMapper的配置

            /*
             * 目前autoMapper只在facade层使用
             *
             * 注册配置：现在这个方法的代码
             * 调用注册配置：StartUp类中的ConfigureServices方法有一行代码：
             *   services.AddMapConfig();
             * 这行代码会调用这个方法注册配置与服务
             *
             * 映射配置：Facede层有一个AutoMapProFile类，在里面编写具体映射规则
             *
             * 如果你的项目不使用AutoMapper，可以删除涉及到的代码
             *
             *
             */

            var config = new AutoMapper.MapperConfiguration(cfg =>
           {
               //配置替换字符，一定要在创建map之前
               //cfg.ReplaceMemberName( "Ä" , "A" );//把源类型属性名中的Ä替换成A

               //添加配置类，以后要添加也在这里添加
               cfg.AddProfile(new AutoMapProFile());

               // 映射具有public或internal的get的属性
               cfg.ShouldMapProperty = p =>
                  p.GetMethod != null
                  && (p.GetMethod.IsPublic || p.GetMethod.IsAssembly);

               //动态创建缺少的映射规则，使用默认的约定
               cfg.CreateMissingTypeMaps = true;
           });

            config.AssertConfigurationIsValid();//启动自动验证映射规则是否正确

            var mapper = config.CreateMapper();
            services.AddSingleton(mapper);
            services.AddSingleton<AutoMapper.IConfigurationProvider>(config);

            return services;
        }
    }
}