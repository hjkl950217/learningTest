﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Mkpl.Sdk.Core;
using Newegg.MIS.Baymax.AOP;
using Newegg.MIS.Baymax.WebApi.Extensions;
using Swashbuckle.AspNetCore.Swagger;
using System;
using System.Collections.Generic;

namespace Mkpl.Item.Service.WebAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            this.Configuration = configuration;
            //todo:新建项目注意-配置类
            //这个类代表web程序的配置，明白后删除此Todo
        }

        public IConfiguration Configuration { get; }

        //配置与注册服务
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            //配置-注册大白
            services.UseBaymax();

            //配置日志等级
            services.AddLogMps();

            //配置-Eggkeeper
            services.AddConfigSerices();

            /*
             * 后缀为MPS的都是公共库中的配置
             *
             * 首先需要调用AddBizService方法注册IOC对应关系
             * 然后需要调用AddConfigSerices获取ConfigServer上的配置
             *
             * 这两个方法最好在UseBaymax之后，因为MPS方法需要从IOC或配置中读取数据
             *
             */
            //配置-IOC映射
            services.AddBizService();

            /*
             *
             * 默认访问Swagger的地址：{host}/Swagger RoutePrefix输出的数据/
             *
             * 因为dotnet-aries需要分组信息，新加一个组后按下面的配置添加一个即可
             * 后续新加的组都写在ConfigList属性中即可
             */

            //配置-Swagger
            services.AddSwaggerMPS(t =>
            {
                t.ConfigList = new List<Info>()
                {
                    //new Info (){ Title ="NISP",Version="v1"}
                };
            });


            //配置-认证服务
            /*
             * 配置项目中免认证的接口
             * key:访问地址 暂时不分get post
             * value:备注说明
             */

            services.AddAuthenticationMPS(t =>
            {
                t.Whitelist.Add(@"/faq", "心跳检测接口");
            });

            //配置-AutoMapper映射
            services.AddMapConfig();

            //注册与配置-MVC
            services.AddMvcCoreMPS(this);

            //注册与配置-API版本控制服务
            services.AddApiVersionMPS();

            //注册与配置-MPS组HttpClient
            services.AddHttpClientMPS();

            //配置-Nair
            services.AddNairCacheMPS();
            /*
             *
             * 什么都不写的情况下，直接调用和下面等价
             *
             */
            //var nairConfig = this.Configuration.GetFromJson<NairSDKSettings>("NairSDKSettings");
            //services.AddNairCacheMPS(opt =>
            //{
            //    //使用了LogCategoryName这个字段名当Nair数据库名
            //    opt.DatebaseName = this.Configuration["LogCategoryName"];
            //}
            //, nairConfig);

            //注册链路追踪服务
            services.AddNeweggTracing();

            //配置-MQ
            services.AddMpsMQClientMPS();

            return services.ToAopProvider();
        }

        //配置HTTP请求流水线
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            /*
             * todo:新建项目注意-Http请求流水线的配置
             *
             * 这个方法是配置请求进来后，中间件的顺序
             *
             * 有些中间件有顺序影响，切记
             *
             * 默认
             */


            //添加链路追踪
            app.UseNeweggTracing("-UseNeweggTracing-");

            //如果是开发环境，启用开发模式
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            //添加swagger中间件
            app.UseSwaggerMPS();

            //添加静态文件中间件
            app.UseStaticFiles();

            //添加跨域策略
            app.UseAllowCORSMPS();

            //启用MPS组的简单异常处理中间件
            app.UseSimpleExceptionHandlerMPS();

            //添加认证中间件
            //app.UseAuthenticationMPS();

            //启用MVC中间件
            app.UseMvc();
        }
    }
}