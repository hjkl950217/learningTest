﻿using Microsoft.AspNetCore.Mvc;
using Mkpl.Item.Facade;

namespace Mkpl.Item.Service.WebAPI.Controllers
{
    [ApiVersion("1.0")]
    [Route("-MainName-/[controller]")]
    [Route("v{version:apiVersion}/-MainName-/[controller]")]
    public class FaqController : ControllerBase
    {
        /// <summary>
        /// 服务器状态
        /// </summary>
        private readonly IServerStatusFacade ServerStatusFacade;

        public FaqController(IServerStatusFacade serverStatusFacade)
        {
            this.ServerStatusFacade = serverStatusFacade;
        }

        /// <summary>
        /// 获取服务器状态
        /// </summary>    
        /// <returns></returns>
        [HttpGet]
        public dynamic Get()
        {
            return this.ServerStatusFacade.IsServerActive();
        }

        /// <summary>
        /// 示例方法
        /// </summary>
        /// <remarks>
        /// <![CDATA[这里可以输入API文档地址]]>
        /// <para>这个标签表示一个段落,备注中最少要写出可以方法的地址</para>
        /// <para>POST item/faq</para>
        /// <para>POST /faq</para>
        /// </remarks>
        /// <returns></returns>
        [HttpPost]
        public dynamic Post()
        {
            //todo:新建项目注意-API示例
            //这是一个API编写示例，开发时删除注释与代码
            return null;
        }

    }
}