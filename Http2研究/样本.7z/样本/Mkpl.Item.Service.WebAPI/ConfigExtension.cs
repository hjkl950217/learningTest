﻿using Microsoft.Extensions.DependencyInjection;
using Mkpl.Item.DataAccess;
using Mkpl.Item.Facade;
using Mkpl.Item.Repository;
using Newegg.MIS.EggKeeper.Sdk.Default;

namespace Mkpl.Item.Service.WebAPI
{
    /// <summary>
    /// web配置类
    /// </summary>
    public static class ConfigExtension
    {
        /// <summary>
        /// 向IOC中注册接口与实例的关系
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddBizService(this IServiceCollection services)
        {
            //纯逻辑的用AddSingleton注册成为-------------单例，速度快
            //有上下文关系的用AddScoped注册为------------在单次请求中都存活
            //临时服务用AddTransient注册为---------------生命周期同new出来的对象一样

            services
               //业务层
               .AddSingleton<IServerStatusService , ServerStatusService>()

               //Facade层
               .AddSingleton<IServerStatusFacade , ServerStatusFacade>()

               //缓存层

               .AddSingleton<IServerStatusDAL , ServerStatusDAL>()

               //DB层
               .AddSingleton<IServerStatusDao , ServerStatusDao>()

               //其他

               ;

            return services;
        }

        /// <summary>
        /// 注册EggKeeper与配置IConfigHelper
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddConfigSerices(this IServiceCollection services)
        {
            //注册EggKeeper
            services.AddEggKeeper();

            //要从配置上读取的数据
            services.UseEggKeeperSimplizer()

                //MKPL_Common

                //MKPL_Item

                //.AddSingletonConfiguration<Demo>()
                ;

            //todo:新建项目注意-读取ConfigService上的配置
            /*
             *
             * 上面现有2行代码不动
             * 后续新加或引用配置时 按上面的格式加就行，并且区分好大节点的名字
             * 一般大节点只会包含MKPL_Common和项目自己的
             *
             */

            return services;
        }
    }
}