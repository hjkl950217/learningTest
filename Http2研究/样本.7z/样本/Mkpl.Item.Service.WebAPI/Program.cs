﻿using Microsoft.AspNetCore.Hosting;
using Mkpl.Sdk.Core.Helpers;

namespace Mkpl.Item.Service.WebAPI
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            //需要调试时请把下面地址的代码复制到本地
            /*
             * 基础配置类，用于构建IwebHost实例
             * ProgramHelper:http://trgit2/mkpl/mkpl-sdk-core/blob/develop/src/Mkpl.Sdk.Core/Helpers/ProgramHelper.cs
             *
             *
             * MpsRun方法的代码，用于执行启动
             * ProgramHelperExtensions:http://trgit2/mkpl/mkpl-sdk-core/blob/develop/src/Mkpl.Sdk.Core/%7BExtensions%7D/IWebHostExtensions.cs
             *
             */

            new ProgramHelper<Startup>("-MainName-", args)
                .MpsRun();

            //todo:（重要）新建项目注意-新建一个配置节点
            /*
             * 启动时会默认从Config Service上获取配置
             * 
             * 默认会获取MKPL_Common和MKPL_-ConfigServiceName-
             * 
             * 所以需要确保Config Service上有MKPL_-ConfigServiceName-这个大节点
             * 否则会报Newegg.MIS.Zookeeper.KeeperException+NoNodeException的错误
             * 
             */

            //todo:（重要）新建项目注意-SQL文件设置
            /*
             * 注意大小写！！
             * 不要修改文件夹名字！！
             * 新加文件，文件的属性设置为：
             * 1.总是复制(英文版本叫：copy always )
             * 2.类型为内容(英文版本叫：content)
             * 
             */


        }
    }
}