﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ServerStatusService.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   ServerStatusService created at  2/24/2018 2:37:41 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
using Mkpl.Item.DataAccess;
using System;
using System.IO;

namespace Mkpl.Item.Service
{
    /// <summary>
    /// 服务器状态检查实现
    /// </summary>
    public class ServerStatusService : IServerStatusService
    {
        /// <summary>
        /// 服务器状态检查接口实例
        /// </summary>
        private readonly IServerStatusDao ServerStatusDataService;

        public ServerStatusService(IServerStatusDao serverStatusDataService)
        {
            this.ServerStatusDataService = serverStatusDataService;
        }

        public string IsServerActive()
        {
            var responseMsg = string.Empty;

            try
            {
                //先判断服务是否下线
                if( this.IsOffLine() == false )
                {
                    responseMsg = "<!--##--> <br/> the server off line.<br/>";
                }
                //再判断数据库服务是否下线
                else
                {
                    var isDatabaseMaintenance = this.ServerStatusDataService.IsDatabaseMaintenance();

                    responseMsg = isDatabaseMaintenance
                        ? "<!--##--> <br/> DataBase is being maintained<br/>"
                        : "<!--Newegg-->";
                }
            }
            catch( Exception ex )
            {
                responseMsg = "<!--##--> <br/> Exception Msg: <br/> " + ex.Message + "<br/>";
                if( ex.InnerException != null )
                {
                    responseMsg += "<br/>*********************************************************************************************************************************************************<br/>";
                    responseMsg += "<br/>InnerException Msg:<br/>" + ex.InnerException;
                }
            }

            return responseMsg;
        }

        /// <summary>
        /// 服务是否离线
        /// </summary>
        /// <remarks>
        /// 如果把FAQ.htm文件拿下，代表服务器正在维护
        /// </remarks>
        /// <returns></returns>
        private bool IsOffLine()
        {
            string faqPath = Path.Combine(Directory.GetCurrentDirectory() + @"/wwwroot/faq.htm");

            return File.Exists(faqPath);
        }
    }
}