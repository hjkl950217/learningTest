﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Item.Reference
{
  public  class ISellerRef
    {
        //todo:新建项目注意-调用其它API
        /*
         * 层级结构就是现在这样看到的
         * 
         * {MKPL}
         *      {Seller}
         *      
         *  针对Seller微服务的调用都会在这里。也可以建立对应的DTO文件夹
         * 
         * 
         */

    }
}
