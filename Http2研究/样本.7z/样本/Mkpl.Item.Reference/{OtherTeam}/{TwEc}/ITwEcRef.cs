﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Item.Reference
{
    class ITwEcRef
    {
        //todo:示例调用其它团队的的API层级结构
    }
}
