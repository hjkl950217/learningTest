﻿namespace Gmp.DevOpsService.Model.Enum
{
    /// <summary>
    /// 发版类型
    /// </summary>
    public enum ReleaseType
    {
        /// <summary>
        /// 无
        /// </summary>
        None = 0,

        /// <summary>
        /// 第一周
        /// </summary>
        Week1 = 10,

        /// <summary>
        /// 第二周
        /// </summary>
        Week2 = 20
    }
}