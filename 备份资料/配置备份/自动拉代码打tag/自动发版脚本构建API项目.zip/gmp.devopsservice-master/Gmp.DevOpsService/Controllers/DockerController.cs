﻿using System;
using System.ComponentModel.DataAnnotations;
using Gmp.DevOpsService.Model.Enum;
using Gmp.DevOpsService.Services.Docker;
using Microsoft.AspNetCore.Mvc;

namespace Gmp.DevOpsService.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DockerController : ControllerBase
    {
        private readonly IDockerService dockerService;

        public DockerController(IDockerService dockerService)
        {
            this.dockerService = dockerService;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="releaseType"></param>
        /// <param name="releaseVersionStr"></param>
        /// <param name="releaseTimeStr"></param>
        /// <returns></returns>
        [HttpGet("ReleaseScript")]
        public string GetReleaseScript(
            [FromQuery, Required] ReleaseType releaseType,
            [FromQuery, Required] string releaseVersionStr,
            [FromQuery] string releaseTimeStr)
        {
            bool isreleaseTime = DateTime.TryParse(releaseTimeStr, out DateTime releaseTime);
            releaseTime = isreleaseTime ? releaseTime : DateTime.Now;

            return this.dockerService.BuildReleaseScript(
                releaseType,
                releaseTime,
                releaseVersionStr);
        }
    }
}