﻿using System;
using Gmp.DevOpsService.Model.Enum;

namespace Gmp.DevOpsService.Services.Docker
{
    public interface IDockerService
    {
        /// <summary>
        /// 构建发版脚本
        /// </summary>
        /// <param name="releaseType">发版类型</param>
        /// <param name="releaseTime">发版时间</param>
        /// <param name="releaseVersionStr">版本字符串,如 5.5.2</param>
        /// <returns></returns>
        string BuildReleaseScript(
           ReleaseType releaseType,
           DateTime releaseTime,
           string releaseVersionStr);
    }
}