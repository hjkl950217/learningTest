﻿using System.Collections.Generic;

namespace Gmp.DevOpsService.Services.Docker.BuildReleaseScript
{
    public static class BuildReleaseScriptContextExtensions
    {
        #region 第一周

        public static BuildReleaseScriptContext AddPullScriptByWeek1(
            this BuildReleaseScriptContext context,
            string stepTittle = "#第一周--拉取")
        {
            context.ScriptBulder.AppendLine(stepTittle);
            ReleaseScriptSourceConfig sourceConfig = context.SourceConfig;

            foreach (string item in sourceConfig.ProductRepositores)
            {
                context.ScriptBulder.AppendLine(@$"docker pull {sourceConfig.DockerRepositoryHost}/{sourceConfig.DockerDevelopRepositoryName}/{item}:latest");
            }

            return context;
        }

        public static BuildReleaseScriptContext AddRenameScriptByWeek1(
            this BuildReleaseScriptContext context,
             string stepTittle = "#第一周--改名")
        {
            context.ScriptBulder.AppendLine(stepTittle);

            ReleaseScriptSourceConfig sourceConfig = context.SourceConfig;
            foreach (string item in sourceConfig.ProductRepositores)
            {
                string sourceTag = $@"{sourceConfig.DockerRepositoryHost}/{sourceConfig.DockerDevelopRepositoryName}/{item}:latest";

                string targetTag = $@"{sourceConfig.DockerRepositoryHost}/{sourceConfig.DockerReleaseRepositoryName}/{item}:{context.ReleaseTime:yyyyMMdd}";

                context.ScriptBulder.AppendLine(@$"docker tag {sourceTag} {targetTag}");
            }

            return context;
        }

        public static BuildReleaseScriptContext AddPushScriptByWeek1(
            this BuildReleaseScriptContext context,
            string stepTittle = "#第一周--推送")
        {
            context.ScriptBulder.AppendLine(stepTittle);

            ReleaseScriptSourceConfig sourceConfig = context.SourceConfig;
            foreach (string item in sourceConfig.ProductRepositores)
            {
                string pushTag = $@"{sourceConfig.DockerRepositoryHost}/{sourceConfig.DockerReleaseRepositoryName}/{item}:{context.ReleaseTime:yyyyMMdd}";

                context.ScriptBulder.AppendLine(@$"docker push {pushTag}");
            }

            return context;
        }

        #endregion 第一周

        public static BuildReleaseScriptContext AddPullScriptByWeek2(
            this BuildReleaseScriptContext context,
            string stepTittle = "#第二周--拉取")
        {
            context.AddPullScriptByWeek1(stepTittle);

            return context;
        }

        public static BuildReleaseScriptContext AddRenameScriptByWeek2(
            this BuildReleaseScriptContext context,
            string stepTittle = "#第二周--改名")
        {
            context.AddRenameScriptByWeek1(stepTittle);

            //附加带版本号
            ReleaseScriptSourceConfig sourceConfig = context.SourceConfig;
            foreach (string item in sourceConfig.ProductRepositores)
            {
                string sourceTag = $@"{sourceConfig.DockerRepositoryHost}/{sourceConfig.DockerDevelopRepositoryName}/{item}:latest";

                string targetTag = $@"{sourceConfig.DockerRepositoryHost}/{sourceConfig.DockerReleaseRepositoryName}/{item}:{context.ReleaseVersionStr}";

                context.ScriptBulder.AppendLine(@$"docker tag {sourceTag} {targetTag}");
            }

            return context;
        }

        public static BuildReleaseScriptContext AddPushScriptByWeek2(
            this BuildReleaseScriptContext context,
            string stepTittle = "#第二周--推送")
        {
            context.AddPushScriptByWeek1(stepTittle);

            //附加带版本号
            ReleaseScriptSourceConfig sourceConfig = context.SourceConfig;
            foreach (string item in sourceConfig.ProductRepositores)
            {
                string pushTag = $@"{sourceConfig.DockerRepositoryHost}/{sourceConfig.DockerReleaseRepositoryName}/{item}:{context.ReleaseVersionStr}";

                context.ScriptBulder.AppendLine(@$"docker push {pushTag}");
            }

            return context;
        }

        public static BuildReleaseScriptContext AddGitScriptByWeek2(
            this BuildReleaseScriptContext context,
            string stepTittle = "#第二周--Git")
        {
            context.ScriptBulder.AppendLine(stepTittle);
            context.ScriptBulder.AppendLine("#Git添加tag部分请在本地运行");

            ReleaseScriptSourceConfig sourceConfig = context.SourceConfig;
            foreach (KeyValuePair<string, string> item in sourceConfig.LocalGitAddress)
            {
                context.ScriptBulder.AppendLine($"#Tag-{item.Key}");
                context.ScriptBulder.AppendLine($"cd {item.Value}");
                context.ScriptBulder.AppendLine("git add .");
                context.ScriptBulder.AppendLine("git checkout remotes/origin/develop_latset");
                context.ScriptBulder.AppendLine("git pull");
                context.ScriptBulder.AppendLine($"git tag -a {context.ReleaseVersionStr} -m \"{context.ReleaseVersionStr}-{context.ReleaseTime:yyyyMMdd}\"");
                context.ScriptBulder.AppendLine("git push origin 5.5.2");
            }

            return context;
        }
    }
}