﻿using System;
using System.Text;
using Gmp.DevOpsService.Model.Enum;

namespace Gmp.DevOpsService.Services.Docker.BuildReleaseScript
{
    public class BuildReleaseScriptContext
    {
        /// <summary>
        ///
        /// </summary>
        /// <param name="configFileAddress">配置文件地址，相对路劲或绝对路径，包括文件名</param>
        /// <param name="releaseType"></param>
        /// <param name="releaseTime"></param>
        /// <param name="releaseVersionStr"></param>
        public BuildReleaseScriptContext(
            string configFileAddress,
            ReleaseType releaseType,
            DateTime releaseTime,
            string releaseVersionStr)
        {
            this.SourceConfig = System.IO.File.ReadAllText(configFileAddress, Encoding.UTF8)
                .ToObjectExt<ReleaseScriptSourceConfig>();

            this.ReleaseType = releaseType;
            this.ReleaseTime = releaseTime;
            this.ReleaseVersionStr = releaseVersionStr;

            this.ScriptBulder = new StringBuilder();
        }

        /// <summary>
        /// 发版原始配置
        /// </summary>
        public ReleaseScriptSourceConfig SourceConfig { get; set; }

        /// <summary>
        /// 发版类型
        /// </summary>
        public ReleaseType ReleaseType { get; set; }

        /// <summary>
        /// 发版时间
        /// </summary>
        public DateTime ReleaseTime { get; set; }

        /// <summary>
        /// 版本字符串,如 5.5.2
        /// </summary>
        public string ReleaseVersionStr { get; set; }

        /// <summary>
        /// 发版脚本
        /// </summary>
        public StringBuilder ScriptBulder { get; set; }
    }
}