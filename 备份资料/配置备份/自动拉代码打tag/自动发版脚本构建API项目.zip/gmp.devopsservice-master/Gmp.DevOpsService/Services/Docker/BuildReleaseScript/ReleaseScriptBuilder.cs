﻿using Gmp.DevOpsService.Model.Enum;

namespace Gmp.DevOpsService.Services.Docker.BuildReleaseScript
{
    public class ReleaseScriptBuildManger
    {
        public string BuildReleaseScript(
            BuildReleaseScriptContext context)
        {
            if (context.ReleaseType == ReleaseType.Week1)
            {
                context
                    .AddPullScriptByWeek1()
                    .AddRenameScriptByWeek1()
                    .AddPushScriptByWeek1();
            }
            else if (context.ReleaseType == ReleaseType.Week2)
            {
                context
                    .AddPullScriptByWeek2()
                    .AddRenameScriptByWeek2()
                    .AddPushScriptByWeek2()
                    .AddGitScriptByWeek2();
            }
            else
            {
            }

            return context.ScriptBulder.ToString();
        }
    }
}