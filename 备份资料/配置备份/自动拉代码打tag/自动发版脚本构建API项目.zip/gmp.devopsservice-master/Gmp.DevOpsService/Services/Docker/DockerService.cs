﻿using System;
using Gmp.DevOpsService.Model.Enum;
using Gmp.DevOpsService.Services.Docker.BuildReleaseScript;

namespace Gmp.DevOpsService.Services.Docker
{
    public class DockerService : IDockerService
    {
        public string BuildReleaseScript(
            ReleaseType releaseType,
            DateTime releaseTime,
            string releaseVersionStr)
        {
            BuildReleaseScriptContext context = new BuildReleaseScriptContext(
                @"Services\Docker\BuildReleaseScript\DockerPushConfig.json",
                releaseType,
                releaseTime,
                releaseVersionStr);

            return new ReleaseScriptBuildManger().BuildReleaseScript(context);
        }
    }
}