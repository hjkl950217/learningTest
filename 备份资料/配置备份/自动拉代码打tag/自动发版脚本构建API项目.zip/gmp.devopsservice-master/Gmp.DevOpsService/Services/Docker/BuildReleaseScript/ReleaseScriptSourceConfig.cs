﻿using System.Collections.Generic;

namespace Gmp.DevOpsService.Services.Docker.BuildReleaseScript
{
    /// <summary>
    /// 发版原始配置
    /// </summary>
    public class ReleaseScriptSourceConfig
    {
        /// <summary>
        /// docker仓库host
        /// </summary>
        public string DockerRepositoryHost { get; set; }

        /// <summary>
        /// docker仓库开发仓库
        /// </summary>
        public string DockerDevelopRepositoryName { get; set; }

        /// <summary>
        /// docker仓库发版仓库
        /// </summary>
        public string DockerReleaseRepositoryName { get; set; }

        /// <summary>
        /// 产品仓库名集合
        /// </summary>
        public string[] ProductRepositores { get; set; }

        /// <summary>
        /// 本地git仓库地址,key为产品名,value为本地仓库绝对地址
        /// </summary>
        public Dictionary<string, string> LocalGitAddress { get; set; }
    }
}