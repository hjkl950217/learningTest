using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;

namespace Gmp.DevOpsService
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddGmpMvcCore(this);
            services.AddGmpSwagger();

            RegistrationServices.Registration(services);
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseRouting();

            app.UseGmpSwagger("DevOpsService");

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}