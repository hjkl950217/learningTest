﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/22 星期四 10:45:45
*
***************************************************************************/

using Gmp.DevOpsService.Services.Docker;
using Microsoft.Extensions.DependencyInjection;

namespace Gmp.DevOpsService
{
    /// <summary>
    /// 服务注册类
    /// </summary>
    public static class RegistrationServices
    {
        /// <summary>
        /// 注册服务
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection Registration(this IServiceCollection services)
        {
            //web层

            //表单代理层

            //服务层
            services.AddScoped<IDockerService, DockerService>();

            //基础设施
            //services.AddScoped<IFolderAppService>(t => EDoc2.Sdk.ServiceContainer.GetService<IFolderAppService>());

            //DB层

            return services;
        }
    }
}